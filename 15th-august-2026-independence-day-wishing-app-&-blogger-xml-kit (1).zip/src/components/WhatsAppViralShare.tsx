import React, { useState } from 'react';
import { LanguageData } from '../types';
import { Share2, Send, Copy, Check, MessageCircle, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface WhatsAppViralShareProps {
  currentLang: LanguageData;
  senderName: string;
  onUpdateSenderName: (name: string) => void;
}

export const WhatsAppViralShare: React.FC<WhatsAppViralShareProps> = ({
  currentLang,
  senderName,
  onUpdateSenderName,
}) => {
  const [inputName, setInputName] = useState(senderName);
  const [copied, setCopied] = useState(false);

  const getShareUrl = (nameToUse: string) => {
    if (typeof window === 'undefined') return '';
    const baseUrl = window.location.origin + window.location.pathname;
    const cleanName = encodeURIComponent(nameToUse.trim() || 'A Proud Indian');
    return `${baseUrl}?name=${cleanName}&lang=${currentLang.key}`;
  };

  const handleGenerateWish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputName.trim()) return;
    onUpdateSenderName(inputName.trim());
    confetti({
      particleCount: 100,
      spread: 70,
      colors: ['#FF9933', '#FFFFFF', '#138808']
    });
  };

  const handleWhatsAppShare = () => {
    const activeName = inputName.trim() || senderName || 'A Proud Indian';
    onUpdateSenderName(activeName);
    const shareUrl = getShareUrl(activeName);
    const message = currentLang.viralMessageTemplate(activeName, shareUrl);

    confetti({
      particleCount: 120,
      spread: 90,
      colors: ['#25D366', '#FF9933', '#138808']
    });

    const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleCopyLink = () => {
    const activeName = inputName.trim() || senderName || 'A Proud Indian';
    const shareUrl = getShareUrl(activeName);
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div id="viral-share-container" className="w-full max-w-xl mx-auto space-y-4">
      {/* Name Input & Customizer */}
      <div className="bg-white/95 backdrop-blur-md rounded-3xl border-2 border-orange-300 shadow-xl p-5 sm:p-7 text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Sparkles className="w-5 h-5 text-orange-600" />
          <h3 className="text-lg sm:text-xl font-extrabold text-slate-900">
            {currentLang.createWishBtn}
          </h3>
        </div>
        <p className="text-xs sm:text-sm text-slate-600 mb-4">
          Type your name below to create a personalized musical Tiranga wish card for your friends!
        </p>

        <form onSubmit={handleGenerateWish} className="space-y-3">
          <div className="relative">
            <input
              type="text"
              id="user-name-input-field"
              value={inputName}
              onChange={(e) => setInputName(e.target.value)}
              placeholder={currentLang.enterNamePlaceholder}
              maxLength={28}
              className="w-full px-5 py-3.5 rounded-2xl border-2 border-orange-300 focus:border-orange-500 focus:ring-4 focus:ring-orange-100 text-slate-900 font-bold text-center text-base sm:text-lg outline-none transition-all placeholder:font-normal placeholder:text-slate-400 shadow-inner"
            />
          </div>

          <button
            type="submit"
            id="create-personal-wish-btn"
            className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-500 to-green-600 hover:brightness-105 active:scale-98 text-white font-black text-base shadow-lg shadow-orange-500/25 transition-all flex items-center justify-center gap-2"
          >
            <Sparkles className="w-5 h-5 text-yellow-200" />
            <span>{currentLang.createWishBtn}</span>
          </button>
        </form>

        {/* Primary Viral WhatsApp CTA */}
        <div className="mt-4 pt-4 border-t border-slate-100 space-y-2.5">
          <button
            id="main-whatsapp-share-btn"
            onClick={handleWhatsAppShare}
            className="w-full py-4 px-6 rounded-2xl bg-[#25D366] hover:bg-[#20bd5a] active:scale-98 text-white font-black text-base sm:text-lg shadow-xl shadow-[#25D366]/35 transition-all flex items-center justify-center gap-3 animate-bounce"
            style={{ animationDuration: '2.5s' }}
          >
            <MessageCircle className="w-6 h-6 fill-white text-[#25D366]" />
            <span>{currentLang.shareOnWhatsAppBtn}</span>
          </button>

          {/* Copy Link & Social Row */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              id="copy-shareable-link-btn"
              onClick={handleCopyLink}
              className="py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors border border-slate-200"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-green-600" />
                  <span className="text-green-700 font-semibold">Link Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-500" />
                  <span>{currentLang.copyLinkBtn}</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                const activeName = inputName.trim() || senderName || 'A Proud Indian';
                const shareUrl = getShareUrl(activeName);
                const text = currentLang.viralMessageTemplate(activeName, shareUrl);
                window.open(`https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(text)}`, '_blank');
              }}
              className="py-2.5 px-3 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors shadow-sm"
            >
              <Send className="w-4 h-4" />
              <span>{currentLang.shareOnTelegramBtn}</span>
            </button>
          </div>
        </div>

        {/* Viral Tip Box */}
        <div className="mt-4 p-3 rounded-xl bg-orange-50/80 border border-orange-200/80 text-[11px] sm:text-xs text-orange-900 text-left flex items-start gap-2">
          <span className="text-sm">💡</span>
          <div>
            <strong className="font-bold">Viral Tip:</strong> Sending this wish to 10 WhatsApp groups and friends between August 13th - 15th brings maximum viral reach!
          </div>
        </div>
      </div>
    </div>
  );
};
