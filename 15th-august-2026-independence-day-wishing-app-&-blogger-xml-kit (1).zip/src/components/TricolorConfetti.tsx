import React, { useEffect, useCallback } from 'react';
import confetti from 'canvas-confetti';

interface TricolorConfettiProps {
  triggerBlast?: boolean;
}

export const TricolorConfetti: React.FC<TricolorConfettiProps> = ({ triggerBlast }) => {
  const fireTricolorCelebration = useCallback(() => {
    const count = 100;
    const defaults = {
      origin: { y: 0.7 },
      colors: ['#FF9933', '#FFFFFF', '#138808', '#000080', '#F59E0B']
    };

    function fire(particleRatio: number, opts: confetti.Options) {
      confetti({
        ...defaults,
        ...opts,
        particleCount: Math.floor(count * particleRatio)
      });
    }

    fire(0.25, {
      spread: 26,
      startVelocity: 55,
    });
    fire(0.2, {
      spread: 60,
    });
    fire(0.35, {
      spread: 100,
      decay: 0.91,
      scalar: 0.8
    });
    fire(0.1, {
      spread: 120,
      startVelocity: 25,
      decay: 0.92,
      scalar: 1.2
    });
    fire(0.1, {
      spread: 120,
      startVelocity: 45,
    });
  }, []);

  useEffect(() => {
    // Initial welcome burst
    const timer = setTimeout(() => {
      fireTricolorCelebration();
    }, 600);

    return () => clearTimeout(timer);
  }, [fireTricolorCelebration]);

  useEffect(() => {
    if (triggerBlast) {
      fireTricolorCelebration();
    }
  }, [triggerBlast, fireTricolorCelebration]);

  return null;
};
