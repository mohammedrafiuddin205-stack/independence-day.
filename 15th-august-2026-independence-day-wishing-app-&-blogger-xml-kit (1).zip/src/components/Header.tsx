import React, { useState, useRef, useEffect } from 'react';
import { LanguageKey } from '../types';
import { LANGUAGES } from '../data/languages';
import { Globe, Code, ChevronDown, Check } from 'lucide-react';
import { AudioPlayer } from './AudioPlayer';

interface HeaderProps {
  currentLangKey: LanguageKey;
  onSelectLanguage: (lang: LanguageKey) => void;
  isPlayingAudio: boolean;
  onToggleAudio: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLangKey,
  onSelectLanguage,
  isPlayingAudio,
  onToggleAudio,
}) => {
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  const currentLang = LANGUAGES[currentLangKey];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setLangDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full bg-white/90 backdrop-blur-md border-b border-orange-200/80 shadow-sm transition-all">
      {/* Top Tricolor Decorative Ribbon */}
      <div className="h-1.5 w-full bg-gradient-to-r from-[#FF9933] via-white to-[#138808]" />

      <div className="max-w-4xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-2">
        {/* Language Selector Dropdown */}
        <div className="relative" ref={dropdownRef}>
          <button
            id="language-selector-btn"
            onClick={() => setLangDropdownOpen(!langDropdownOpen)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-50 hover:bg-orange-100/80 text-orange-900 border border-orange-200/80 text-xs sm:text-sm font-bold transition-all shadow-sm"
            aria-label="Select Language"
          >
            <Globe className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-orange-600 shrink-0" />
            <span className="max-w-[90px] sm:max-w-[120px] truncate">{currentLang.nativeLabel}</span>
            <ChevronDown className={`w-3.5 h-3.5 text-orange-600 transition-transform ${langDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {langDropdownOpen && (
            <div className="absolute top-full left-0 mt-1.5 w-56 sm:w-64 bg-white rounded-2xl shadow-2xl border border-orange-200 py-2 z-50 max-h-80 overflow-y-auto">
              <div className="px-3 py-1.5 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100">
                Select Indian Language
              </div>
              {Object.values(LANGUAGES).map((lang) => (
                <button
                  key={lang.key}
                  onClick={() => {
                    onSelectLanguage(lang.key);
                    setLangDropdownOpen(false);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs sm:text-sm flex items-center justify-between hover:bg-orange-50 transition-colors ${
                    currentLangKey === lang.key ? 'bg-orange-50 text-orange-600 font-extrabold' : 'text-slate-700 font-medium'
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span>{lang.flagIcon}</span>
                    <span className="truncate">{lang.nativeLabel}</span>
                    <span className="text-[10px] text-slate-400 font-normal">({lang.label})</span>
                  </div>
                  {currentLangKey === lang.key && <Check className="w-4 h-4 text-orange-600 shrink-0" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Action Cluster */}
        <div className="flex items-center gap-2">
          {/* Audio Player Component */}
          <AudioPlayer
            isPlaying={isPlayingAudio}
            onTogglePlay={onToggleAudio}
            title={currentLang.anthemTitle}
          />
        </div>
      </div>
    </header>
  );
};
