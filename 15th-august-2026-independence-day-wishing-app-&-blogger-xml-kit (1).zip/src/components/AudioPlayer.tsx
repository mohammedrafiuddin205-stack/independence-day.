import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Music, Play, Pause } from 'lucide-react';

interface AudioPlayerProps {
  isPlaying: boolean;
  onTogglePlay: () => void;
  title: string;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ isPlaying, onTogglePlay, title }) => {
  const [synthActive, setSynthActive] = useState<boolean>(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<number | null>(null);

  // Patriotic Melody synthesized notes (Frequencies for Jana Gana Mana / Vande Mataram motif)
  // [Frequency, Duration (ms)]
  const melodyNotes: [number, number][] = [
    [523.25, 350], // C5
    [587.33, 350], // D5
    [659.25, 400], // E5
    [659.25, 400], // E5
    [659.25, 400], // E5
    [659.25, 400], // E5
    [659.25, 300], // E5
    [587.33, 300], // D5
    [659.25, 400], // E5
    [698.46, 500], // F5
    [659.25, 400], // E5
    [587.33, 400], // D5
    [523.25, 600], // C5
    // Vande Mataram motif
    [659.25, 400], // E5
    [783.99, 450], // G5
    [880.00, 600], // A5
    [783.99, 400], // G5
    [659.25, 600], // E5
    [587.33, 500], // D5
    [523.25, 700], // C5
  ];

  const playTone = (freq: number, duration: number) => {
    try {
      if (!audioCtxRef.current) {
        const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        audioCtxRef.current = new AudioContextClass();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      // Warm flute-like harmonic timbre
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.01, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (duration / 1000) - 0.02);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + (duration / 1000));
    } catch {
      // Ignore audio policy errors
    }
  };

  useEffect(() => {
    let noteIndex = 0;
    if (isPlaying) {
      setSynthActive(true);
      const scheduleNextNote = () => {
        if (!isPlaying) return;
        const [freq, dur] = melodyNotes[noteIndex % melodyNotes.length];
        playTone(freq, dur);
        noteIndex++;
        timerRef.current = window.setTimeout(scheduleNextNote, dur + 60);
      };
      scheduleNextNote();
    } else {
      setSynthActive(false);
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    }

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isPlaying]);

  return (
    <div id="audio-player-control" className="flex items-center gap-2 bg-white/95 backdrop-blur-md border border-amber-200/80 shadow-md px-3 py-1.5 rounded-full">
      <button
        id="toggle-audio-btn"
        onClick={onTogglePlay}
        className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-amber-900 hover:text-orange-600 transition-colors"
        aria-label="Toggle patriotic music"
      >
        {isPlaying ? (
          <div className="flex items-center gap-1.5 text-orange-600">
            <Volume2 className="w-4 h-4 animate-pulse text-orange-600" />
            <span className="hidden sm:inline">Deshbhakti Music: ON</span>
            <span className="sm:hidden">ON</span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-slate-500">
            <VolumeX className="w-4 h-4 text-slate-400" />
            <span className="hidden sm:inline">Music: OFF</span>
            <span className="sm:hidden">OFF</span>
          </div>
        )}
      </button>

      {isPlaying && (
        <div className="flex items-end gap-0.5 h-3 px-1">
          <span className="w-0.5 h-full bg-orange-500 animate-bounce rounded-full" style={{ animationDelay: '0ms' }}></span>
          <span className="w-0.5 h-2 bg-amber-400 animate-bounce rounded-full" style={{ animationDelay: '150ms' }}></span>
          <span className="w-0.5 h-3.5 bg-green-600 animate-bounce rounded-full" style={{ animationDelay: '300ms' }}></span>
          <span className="w-0.5 h-1.5 bg-blue-700 animate-bounce rounded-full" style={{ animationDelay: '75ms' }}></span>
        </div>
      )}
    </div>
  );
};
