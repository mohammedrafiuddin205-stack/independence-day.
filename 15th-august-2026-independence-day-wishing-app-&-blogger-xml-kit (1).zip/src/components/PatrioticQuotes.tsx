import React, { useState } from 'react';
import { LanguageData } from '../types';
import { Quote, Copy, Check, MessageSquare, Heart } from 'lucide-react';

interface PatrioticQuotesProps {
  currentLang: LanguageData;
}

export const PatrioticQuotes: React.FC<PatrioticQuotesProps> = ({ currentLang }) => {
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const handleCopyQuote = (text: string, author: string, idx: number) => {
    const fullText = `🇮🇳 "${text}" — ${author} (Happy 15th August 2026! Vande Mataram!)`;
    navigator.clipboard.writeText(fullText);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const handleShareQuote = (text: string, author: string) => {
    const fullText = `🇮🇳 *15th AUGUST PATRIOTIC STATUS* 🇮🇳\n\n"${text}"\n\n— *${author}*\n\n_Happy 80th Independence Day 2026! Jai Hind!_ 🇮🇳`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(fullText)}`, '_blank');
  };

  return (
    <div id="patriotic-quotes-root" className="w-full max-w-xl mx-auto space-y-4">
      <div className="bg-white/90 backdrop-blur-md rounded-3xl border-2 border-orange-200/80 shadow-xl p-5 sm:p-7">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center p-2 rounded-2xl bg-orange-100 text-orange-600 mb-2">
            <Quote className="w-6 h-6" />
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900">
            {currentLang.quotesTitle}
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            {currentLang.quotesSubtitle}
          </p>
        </div>

        <div className="space-y-4">
          {currentLang.shayariList.map((item, idx) => (
            <div
              key={idx}
              className="relative p-4 rounded-2xl bg-gradient-to-br from-amber-50/70 via-white to-green-50/70 border border-slate-200/80 shadow-sm hover:shadow-md transition-all group"
            >
              <p className="text-sm sm:text-base font-semibold text-slate-800 leading-relaxed italic">
                &ldquo;{item.quote}&rdquo;
              </p>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
                <span className="text-xs font-bold text-orange-600 flex items-center gap-1">
                  <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
                  {item.author}
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopyQuote(item.quote, item.author, idx)}
                    className="p-1.5 rounded-lg bg-white hover:bg-slate-100 text-slate-600 text-xs font-semibold flex items-center gap-1 border border-slate-200 transition-colors"
                    title="Copy Shayari"
                  >
                    {copiedIdx === idx ? (
                      <Check className="w-3.5 h-3.5 text-green-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span className="text-[11px]">{copiedIdx === idx ? 'Copied' : 'Copy'}</span>
                  </button>

                  <button
                    onClick={() => handleShareQuote(item.quote, item.author)}
                    className="p-1.5 rounded-lg bg-[#25D366]/10 hover:bg-[#25D366]/20 text-[#25D366] text-xs font-semibold flex items-center gap-1 transition-colors"
                    title="Share to WhatsApp Status"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span className="text-[11px]">Status</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
