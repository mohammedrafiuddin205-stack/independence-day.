import React, { useState, useRef, useEffect } from 'react';
import { LanguageData } from '../types';
import { Camera, Download, RefreshCw, Image as ImageIcon, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

interface DpFrameGeneratorProps {
  currentLang: LanguageData;
  senderName: string;
}

export const DpFrameGenerator: React.FC<DpFrameGeneratorProps> = ({ currentLang, senderName }) => {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [selectedFrame, setSelectedFrame] = useState<number>(0);
  const [customBadgeName, setCustomBadgeName] = useState<string>(senderName || '');
  const [isGenerating, setIsGenerating] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (senderName && !customBadgeName) {
      setCustomBadgeName(senderName);
    }
  }, [senderName, customBadgeName]);

  const frames = [
    {
      id: 'tricolor-glow',
      name: 'Tricolor Pride Glow',
      badge: '🇮🇳 PROUD INDIAN',
      theme: 'from-orange-500 via-white to-green-600'
    },
    {
      id: 'har-ghar-tiranga',
      name: 'Har Ghar Tiranga 2026',
      badge: '✨ HAR GHAR TIRANGA',
      theme: 'from-orange-600 to-green-700'
    },
    {
      id: 'jai-hind-gold',
      name: 'Jai Hind 80th Year',
      badge: '🫡 80th AZADI MAHOTSAV',
      theme: 'from-amber-400 via-orange-500 to-green-600'
    },
    {
      id: 'vande-mataram',
      name: 'Vande Mataram Badge',
      badge: '🚩 VANDE MATARAM',
      theme: 'from-orange-500 to-blue-900'
    }
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setImageSrc(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const size = 800;
    canvas.width = size;
    canvas.height = size;

    // Background fill
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, size);

    if (imageSrc) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        // Draw user image clipped in a circle or full
        ctx.save();
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, size / 2 - 40, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();

        // Calculate aspect ratio cover
        const hRatio = (size - 80) / img.width;
        const vRatio = (size - 80) / img.height;
        const ratio = Math.max(hRatio, vRatio);
        const centerShiftX = (size - img.width * ratio) / 2;
        const centerShiftY = (size - img.height * ratio) / 2;

        ctx.drawImage(img, 0, 0, img.width, img.height, centerShiftX, centerShiftY, img.width * ratio, img.height * ratio);
        ctx.restore();

        // Draw Patriotic Border Ring
        drawBorderOverlay(ctx, size);
      };
      img.src = imageSrc;
    } else {
      // Placeholder drawing
      ctx.save();
      ctx.beginPath();
      ctx.arc(size / 2, size / 2, size / 2 - 40, 0, Math.PI * 2);
      ctx.fillStyle = '#f8fafc';
      ctx.fill();
      ctx.restore();
      drawBorderOverlay(ctx, size);
    }
  };

  const drawBorderOverlay = (ctx: CanvasRenderingContext2D, size: number) => {
    const cx = size / 2;
    const cy = size / 2;
    const radius = size / 2 - 25;

    // Outer Tricolor concentric rings
    // Saffron Arc (Top 120 deg)
    ctx.beginPath();
    ctx.arc(cx, cy, radius, -Math.PI * 0.75, -Math.PI * 0.25);
    ctx.lineWidth = 32;
    ctx.strokeStyle = '#FF9933';
    ctx.stroke();

    // White / Navy Arc
    ctx.beginPath();
    ctx.arc(cx, cy, radius, -Math.PI * 0.25, Math.PI * 0.25);
    ctx.lineWidth = 32;
    ctx.strokeStyle = '#FFFFFF';
    ctx.stroke();

    // Green Arc (Bottom 120 deg)
    ctx.beginPath();
    ctx.arc(cx, cy, radius, Math.PI * 0.25, Math.PI * 0.75);
    ctx.lineWidth = 32;
    ctx.strokeStyle = '#138808';
    ctx.stroke();

    // Secondary Saffron Arc
    ctx.beginPath();
    ctx.arc(cx, cy, radius, Math.PI * 0.75, Math.PI * 1.25);
    ctx.lineWidth = 32;
    ctx.strokeStyle = '#FF9933';
    ctx.stroke();

    // Ashoka Chakra Emblem at top right
    ctx.save();
    ctx.translate(size - 90, 90);
    ctx.beginPath();
    ctx.arc(0, 0, 40, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#000080';
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(0, 0, 7, 0, Math.PI * 2);
    ctx.fillStyle = '#000080';
    ctx.fill();
    for (let i = 0; i < 24; i++) {
      const angle = (i * 360) / 24 * (Math.PI / 180);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(36 * Math.cos(angle), 36 * Math.sin(angle));
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#000080';
      ctx.stroke();
    }
    ctx.restore();

    // Bottom Banner Ribbon
    ctx.save();
    const ribbonY = size - 130;
    const ribbonHeight = 80;
    const ribbonWidth = size - 160;
    const ribbonX = (size - ribbonWidth) / 2;

    // Gradient banner
    const grad = ctx.createLinearGradient(ribbonX, ribbonY, ribbonX + ribbonWidth, ribbonY);
    grad.addColorStop(0, '#FF9933');
    grad.addColorStop(0.5, '#ffffff');
    grad.addColorStop(1, '#138808');

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(ribbonX, ribbonY, ribbonWidth, ribbonHeight, 40);
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#000080';
    ctx.stroke();

    // Text on Banner
    ctx.fillStyle = '#000080';
    ctx.font = 'bold 30px "Poppins", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const textToPrint = customBadgeName ? `${frames[selectedFrame].badge} - ${customBadgeName}` : frames[selectedFrame].badge;
    ctx.fillText(textToPrint, size / 2, ribbonY + ribbonHeight / 2);
    ctx.restore();
  };

  useEffect(() => {
    drawCanvas();
  }, [imageSrc, selectedFrame, customBadgeName]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsGenerating(true);

    confetti({
      particleCount: 80,
      spread: 70,
      colors: ['#FF9933', '#FFFFFF', '#138808']
    });

    const link = document.createElement('a');
    link.download = `Independence-Day-2026-DP-${customBadgeName || 'India'}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();

    setTimeout(() => setIsGenerating(false), 800);
  };

  return (
    <div id="dp-frame-generator-root" className="w-full max-w-xl mx-auto bg-white/90 backdrop-blur-md rounded-3xl border-2 border-orange-200/80 shadow-xl p-5 sm:p-7 text-center">
      <div className="flex items-center justify-center gap-2 mb-1">
        <Camera className="w-6 h-6 text-orange-600" />
        <h3 className="text-xl sm:text-2xl font-black text-slate-900">
          {currentLang.frameTitle}
        </h3>
      </div>
      <p className="text-xs sm:text-sm text-slate-600 mb-5">
        {currentLang.frameSubtitle}
      </p>

      {/* Frame Preview Canvas */}
      <div className="flex justify-center my-4">
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-2xl overflow-hidden shadow-2xl border-4 border-white bg-slate-100 flex items-center justify-center">
          <canvas ref={canvasRef} className="w-full h-full object-contain" />
          {!imageSrc && (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="absolute inset-0 flex flex-col items-center justify-center bg-black/30 hover:bg-black/40 text-white cursor-pointer transition-colors p-4"
            >
              <ImageIcon className="w-10 h-10 mb-2 drop-shadow-md animate-pulse text-amber-300" />
              <span className="text-xs sm:text-sm font-bold drop-shadow">
                Tap to Select Your Photo
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Hidden File Input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />

      {/* Frame Badge Selector */}
      <div className="grid grid-cols-2 gap-2 my-4">
        {frames.map((frame, idx) => (
          <button
            key={frame.id}
            onClick={() => setSelectedFrame(idx)}
            className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all text-left flex items-center justify-between ${
              selectedFrame === idx
                ? 'bg-orange-50 border-orange-500 text-orange-800 shadow-sm'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <span>{frame.name}</span>
            {selectedFrame === idx && <Check className="w-4 h-4 text-orange-600 shrink-0" />}
          </button>
        ))}
      </div>

      {/* Custom Name on Frame */}
      <div className="my-3">
        <input
          type="text"
          value={customBadgeName}
          onChange={(e) => setCustomBadgeName(e.target.value)}
          placeholder="Name on DP Frame (e.g. Rahul Sharma)..."
          maxLength={24}
          className="w-full px-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:border-orange-500 focus:outline-none focus:ring-2 focus:ring-orange-200 text-center font-semibold"
        />
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-2 mt-4">
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex-1 px-4 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors border border-slate-300"
        >
          <RefreshCw className="w-4 h-4" />
          {imageSrc ? 'Change Photo' : currentLang.uploadPhotoBtn}
        </button>

        <button
          id="download-dp-btn"
          onClick={handleDownload}
          disabled={isGenerating}
          className="flex-1 px-4 py-3 rounded-xl bg-gradient-to-r from-orange-500 to-green-600 hover:brightness-105 active:scale-95 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20 transition-all"
        >
          <Download className="w-4 h-4" />
          {currentLang.downloadFrameBtn}
        </button>
      </div>
    </div>
  );
};
