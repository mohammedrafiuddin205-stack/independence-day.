import React, { useState, useEffect } from 'react';
import { LanguageData } from '../types';
import { Sparkles, Heart, Flag, Gift, Award, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface WishingCardProps {
  currentLang: LanguageData;
  senderName: string;
  onSaluteClick: () => void;
  saluteCount: number;
  hasSaluted: boolean;
}

export const WishingCard: React.FC<WishingCardProps> = ({
  currentLang,
  senderName,
  onSaluteClick,
  saluteCount,
  hasSaluted,
}) => {
  // Countdown to 15th August 2026
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  const [isOpened, setIsOpened] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const targetDate = new Date('2026-08-15T00:00:00+05:30').getTime();
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleOpenSurprise = () => {
    setIsOpened(true);
    confetti({
      particleCount: 150,
      spread: 80,
      origin: { y: 0.6 },
      colors: ['#FF9933', '#FFFFFF', '#138808', '#000080', '#FFD700']
    });
  };

  return (
    <div id="wishing-card-root" className="w-full max-w-xl mx-auto space-y-5">
      {/* Top Floating Badge */}
      <div className="flex justify-center">
        <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gradient-to-r from-orange-500 via-amber-500 to-green-600 text-white font-bold text-xs sm:text-sm tracking-wide shadow-md shadow-orange-500/20 animate-pulse">
          <Flag className="w-4 h-4 text-white" />
          {currentLang.yearCelebration}
        </span>
      </div>

      {/* Surprise Gift Envelope Banner (Viral Engagement Hook) */}
      {!isOpened ? (
        <div
          id="surprise-gift-trigger"
          onClick={handleOpenSurprise}
          className="relative overflow-hidden cursor-pointer group bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 p-0.5 rounded-2xl shadow-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-orange-500/30"
        >
          <div className="bg-white/95 backdrop-blur-md rounded-2xl p-5 text-center flex flex-col items-center justify-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 shadow-inner group-hover:rotate-12 transition-transform duration-300">
              <Gift className="w-8 h-8 animate-bounce text-orange-600" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-slate-800">
                {currentLang.surpriseGiftTitle}
              </h3>
              <p className="text-xs sm:text-sm text-orange-600 font-semibold mt-1 animate-pulse">
                👇 {currentLang.tapToOpenText} 👇
              </p>
            </div>
            <button className="px-5 py-2 rounded-full bg-gradient-to-r from-orange-500 to-green-600 text-white font-bold text-xs sm:text-sm shadow-md">
              Tap to Open Gift 🎁
            </button>
          </div>
        </div>
      ) : null}

      {/* Main Patriotic Greeting Card */}
      <div className="relative bg-white/90 backdrop-blur-md rounded-3xl border-2 border-orange-200/80 shadow-2xl p-5 sm:p-7 text-center overflow-hidden">
        {/* Corner Tri-color Accents */}
        <div className="absolute -top-10 -right-10 w-28 h-28 bg-gradient-to-br from-orange-400 to-amber-200 rounded-full blur-2xl opacity-60 pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-28 h-28 bg-gradient-to-tr from-green-500 to-emerald-200 rounded-full blur-2xl opacity-60 pointer-events-none" />

        {/* Sender Name Section with Glowing Effect */}
        <div className="relative bg-gradient-to-r from-orange-50 via-amber-50 to-green-50 rounded-2xl p-4 border border-orange-200/70 shadow-sm mb-5">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
            {currentLang.senderPrefix ? currentLang.senderPrefix : 'Warm Wishes From:'}
          </span>
          <div
            id="personalized-sender-display"
            className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-600 via-rose-600 to-orange-700 tracking-wide uppercase py-1"
          >
            {senderName || 'A Proud Indian'}
          </div>
          <p className="text-xs sm:text-sm font-medium text-slate-700 mt-1">
            {currentLang.senderSuffix}
          </p>
        </div>

        {/* Spinning 24-Spokes Ashoka Chakra */}
        <div className="flex justify-center my-3">
          <div className="relative w-20 h-20 flex items-center justify-center">
            <svg
              className="w-20 h-20 animate-spin text-blue-900"
              style={{ animationDuration: '16s' }}
              viewBox="0 0 100 100"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="50" cy="50" r="46" stroke="#000080" strokeWidth="4" />
              <circle cx="50" cy="50" r="8" fill="#000080" />
              {/* 24 spokes */}
              {[...Array(24)].map((_, i) => {
                const angle = (i * 360) / 24;
                return (
                  <line
                    key={i}
                    x1="50"
                    y1="50"
                    x2={50 + 42 * Math.sin((angle * Math.PI) / 180)}
                    y2={50 - 42 * Math.cos((angle * Math.PI) / 180)}
                    stroke="#000080"
                    strokeWidth="2"
                  />
                );
              })}
            </svg>
          </div>
        </div>

        {/* Happy Independence Day Title */}
        <h1 className="text-3xl sm:text-4xl font-black tracking-tight mt-2 text-slate-900 leading-tight">
          <span className="text-orange-500 drop-shadow-sm">HAPPY </span>
          <span className="text-blue-950">80th </span>
          <span className="text-green-600 drop-shadow-sm">INDEPENDENCE DAY</span>
        </h1>

        <p className="text-base sm:text-lg font-bold text-amber-900 mt-2">
          {currentLang.happyIndependence}
        </p>

        {/* Indian Flag Illustration / High Quality Visual */}
        <div className="my-5 rounded-2xl overflow-hidden shadow-lg border-2 border-white relative group">
          <img
            src="https://images.unsplash.com/photo-1532375810709-75b1da00537c?w=1000&auto=format&fit=crop&q=80"
            alt="Indian National Flag Tiranga Pride"
            className="w-full h-48 sm:h-56 object-cover transition-transform duration-700 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end justify-center p-3">
            <span className="text-white text-sm sm:text-base font-extrabold tracking-wide drop-shadow-md">
              🇮🇳 Vijayi Vishwa Tiranga Pyara, Jhanda Ooncha Rahe Hamara 🇮🇳
            </span>
          </div>
        </div>

        {/* Live Countdown to 15 August 2026 */}
        <div className="bg-amber-50/90 rounded-2xl p-4 border border-amber-200 my-5">
          <div className="text-xs sm:text-sm font-bold uppercase tracking-wider text-amber-900 mb-3 flex items-center justify-center gap-1.5">
            <Sparkles className="w-4 h-4 text-orange-500" />
            15th August 2026 Countdown
          </div>
          <div className="grid grid-cols-4 gap-2 sm:gap-3">
            <div className="bg-white rounded-xl p-2.5 shadow-sm border border-orange-100 flex flex-col items-center">
              <span className="text-xl sm:text-2xl font-black text-orange-600">
                {String(timeLeft.days).padStart(2, '0')}
              </span>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-500 uppercase">
                {currentLang.countdownDays}
              </span>
            </div>
            <div className="bg-white rounded-xl p-2.5 shadow-sm border border-orange-100 flex flex-col items-center">
              <span className="text-xl sm:text-2xl font-black text-blue-900">
                {String(timeLeft.hours).padStart(2, '0')}
              </span>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-500 uppercase">
                {currentLang.countdownHours}
              </span>
            </div>
            <div className="bg-white rounded-xl p-2.5 shadow-sm border border-orange-100 flex flex-col items-center">
              <span className="text-xl sm:text-2xl font-black text-green-600">
                {String(timeLeft.minutes).padStart(2, '0')}
              </span>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-500 uppercase">
                {currentLang.countdownMinutes}
              </span>
            </div>
            <div className="bg-white rounded-xl p-2.5 shadow-sm border border-orange-100 flex flex-col items-center">
              <span className="text-xl sm:text-2xl font-black text-rose-600 animate-pulse">
                {String(timeLeft.seconds).padStart(2, '0')}
              </span>
              <span className="text-[10px] sm:text-xs font-semibold text-slate-500 uppercase">
                {currentLang.countdownSeconds}
              </span>
            </div>
          </div>
        </div>

        {/* National Tricolor Pledge & Flag Salute Button */}
        <div className="bg-gradient-to-r from-orange-50 via-white to-green-50 rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm text-left">
          <div className="flex items-center gap-2 mb-2">
            <Award className="w-5 h-5 text-orange-600" />
            <h4 className="text-sm sm:text-base font-bold text-slate-900">
              {currentLang.pledgeTitle}
            </h4>
          </div>
          <p className="text-xs sm:text-sm text-slate-700 italic leading-relaxed mb-4">
            &ldquo;{currentLang.pledgeText}&rdquo;
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
            <button
              id="salute-flag-btn"
              onClick={onSaluteClick}
              className={`w-full sm:w-auto px-5 py-2.5 rounded-full font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shadow-md ${
                hasSaluted
                  ? 'bg-green-600 text-white shadow-green-600/30'
                  : 'bg-gradient-to-r from-orange-500 to-green-600 text-white hover:brightness-105 active:scale-95 shadow-orange-500/20'
              }`}
            >
              {hasSaluted ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Saluted! Jai Hind! 🫡
                </>
              ) : (
                <>
                  <Flag className="w-4 h-4 text-white" />
                  {currentLang.pledgeActionBtn}
                </>
              )}
            </button>

            <div className="text-[11px] sm:text-xs text-slate-500 font-semibold flex items-center gap-1.5">
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
              <span>{saluteCount.toLocaleString()} Indians Saluted Today</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
