import React, { useState, useEffect } from 'react';
import { LanguageKey } from './types';
import { LANGUAGES } from './data/languages';
import { Header } from './components/Header';
import { WishingCard } from './components/WishingCard';
import { WhatsAppViralShare } from './components/WhatsAppViralShare';
import { DpFrameGenerator } from './components/DpFrameGenerator';
import { PatrioticQuotes } from './components/PatrioticQuotes';
import { TricolorConfetti } from './components/TricolorConfetti';
import { MessageCircle, Flag, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function App() {
  // Extract query parameters from URL (?name=... or ?n=... and ?lang=...)
  const [currentLangKey, setCurrentLangKey] = useState<LanguageKey>('hinglish');
  const [senderName, setSenderName] = useState<string>('');
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [saluteCount, setSaluteCount] = useState<number>(284392);
  const [hasSaluted, setHasSaluted] = useState<boolean>(false);
  const [triggerConfetti, setTriggerConfetti] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlName = params.get('name') || params.get('n');
      const urlLang = params.get('lang') as LanguageKey;

      if (urlName) {
        setSenderName(decodeURIComponent(urlName));
      }
      if (urlLang && LANGUAGES[urlLang]) {
        setCurrentLangKey(urlLang);
      }

      // Read stored salute count
      const storedSalutes = localStorage.getItem('ind_day_salute_count');
      if (storedSalutes) {
        setSaluteCount(parseInt(storedSalutes, 10));
      }
      const userSaluted = localStorage.getItem('ind_day_has_saluted');
      if (userSaluted === 'true') {
        setHasSaluted(true);
      }
    }
  }, []);

  const currentLang = LANGUAGES[currentLangKey] || LANGUAGES.hinglish;

  const handleSaluteClick = () => {
    if (!hasSaluted) {
      const newCount = saluteCount + 1;
      setSaluteCount(newCount);
      setHasSaluted(true);
      localStorage.setItem('ind_day_salute_count', newCount.toString());
      localStorage.setItem('ind_day_has_saluted', 'true');
    }

    setTriggerConfetti(prev => !prev);
    confetti({
      particleCount: 120,
      spread: 90,
      colors: ['#FF9933', '#FFFFFF', '#138808', '#000080']
    });
  };

  const handleUpdateSenderName = (name: string) => {
    setSenderName(name);
    // Update browser URL query without reload
    if (typeof window !== 'undefined') {
      const newUrl = `${window.location.pathname}?name=${encodeURIComponent(name)}&lang=${currentLangKey}`;
      window.history.replaceState({ path: newUrl }, '', newUrl);
    }
  };

  const handleLanguageChange = (langKey: LanguageKey) => {
    setCurrentLangKey(langKey);
    if (typeof window !== 'undefined') {
      const nameParam = senderName ? `&name=${encodeURIComponent(senderName)}` : '';
      const newUrl = `${window.location.pathname}?lang=${langKey}${nameParam}`;
      window.history.replaceState({ path: newUrl }, '', newUrl);
    }
  };

  const handleDirectWhatsAppShare = () => {
    const activeName = senderName || 'A Proud Indian';
    const baseUrl = window.location.origin + window.location.pathname;
    const shareUrl = `${baseUrl}?name=${encodeURIComponent(activeName)}&lang=${currentLangKey}`;
    const message = currentLang.viralMessageTemplate(activeName, shareUrl);

    confetti({
      particleCount: 100,
      spread: 80,
      colors: ['#25D366', '#FF9933', '#138808']
    });

    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-radial from-amber-50/70 via-orange-50/40 to-emerald-50/60 text-slate-800 flex flex-col font-sans pb-28 selection:bg-orange-500 selection:text-white">
      {/* Background Confetti & Celebration Burst */}
      <TricolorConfetti triggerBlast={triggerConfetti} />

      {/* Multilingual Top Header with Language Selector & Audio Toggle */}
      <Header
        currentLangKey={currentLangKey}
        onSelectLanguage={handleLanguageChange}
        isPlayingAudio={isPlayingAudio}
        onToggleAudio={() => setIsPlayingAudio(!isPlayingAudio)}
      />

      {/* Main Content Body */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-6 py-6 sm:py-8 space-y-8 sm:space-y-10">
        
        {/* Multilingual Quick Language Pills Bar for Instant Switching */}
        <section className="w-full max-w-xl mx-auto overflow-x-auto pb-1 flex items-center gap-1.5 scrollbar-none">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider shrink-0 pl-1">
            Language:
          </span>
          {Object.values(LANGUAGES).map((lang) => (
            <button
              key={lang.key}
              onClick={() => handleLanguageChange(lang.key)}
              className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1 ${
                currentLangKey === lang.key
                  ? 'bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-md shadow-orange-500/20 font-bold scale-105'
                  : 'bg-white/80 hover:bg-white text-slate-700 border border-slate-200'
              }`}
            >
              <span>{lang.flagIcon}</span>
              <span>{lang.nativeLabel}</span>
            </button>
          ))}
        </section>

        {/* Primary Interactive Wishing Card */}
        <section id="wishing-card-section">
          <WishingCard
            currentLang={currentLang}
            senderName={senderName}
            onSaluteClick={handleSaluteClick}
            saluteCount={saluteCount}
            hasSaluted={hasSaluted}
          />
        </section>

        {/* Personal Name Generator & 1-Click WhatsApp Viral Share Engine */}
        <section id="whatsapp-viral-section">
          <WhatsAppViralShare
            currentLang={currentLang}
            senderName={senderName}
            onUpdateSenderName={handleUpdateSenderName}
          />
        </section>

        {/* Patriotic DP / Profile Picture Frame Generator */}
        <section id="dp-generator-section">
          <DpFrameGenerator
            currentLang={currentLang}
            senderName={senderName}
          />
        </section>

        {/* Multilingual Patriotic Quotes & Shayari */}
        <section id="patriotic-quotes-section">
          <PatrioticQuotes currentLang={currentLang} />
        </section>

        {/* Footer */}
        <footer className="w-full max-w-xl mx-auto text-center space-y-3 pt-6 border-t border-orange-200/80 text-xs text-slate-500">
          <div className="flex items-center justify-center gap-2 font-bold text-slate-700 text-sm">
            <Flag className="w-4 h-4 text-orange-600" />
            <span>15th August 2026 - 80th Independence Day Celebration</span>
            <Flag className="w-4 h-4 text-green-600" />
          </div>
          <p>
            Dedicated with pride and love to all citizens and freedom fighters of our beloved motherland India.
          </p>
          <div className="flex items-center justify-center gap-1 text-slate-400 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>100% Free Multilingual Independence Day Wishing Portal</span>
          </div>
        </footer>
      </main>

      {/* Sticky Bottom Viral WhatsApp CTA Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 p-2.5 sm:p-3 shadow-2xl flex items-center justify-center">
        <div className="max-w-xl w-full flex items-center gap-2">
          <button
            id="sticky-whatsapp-share-btn"
            onClick={handleDirectWhatsAppShare}
            className="flex-1 py-3 px-4 rounded-full bg-[#25D366] hover:bg-[#20bd5a] active:scale-98 text-white font-black text-sm sm:text-base shadow-lg shadow-[#25D366]/40 transition-all flex items-center justify-center gap-2 animate-bounce"
            style={{ animationDuration: '2.5s' }}
          >
            <MessageCircle className="w-5 h-5 fill-white text-[#25D366]" />
            <span>👉 Send Wish on WhatsApp (10 Friends) 🚀</span>
          </button>
        </div>
      </div>
    </div>
  );
}
