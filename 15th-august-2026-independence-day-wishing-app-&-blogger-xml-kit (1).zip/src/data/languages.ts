import { LanguageData, LanguageKey } from '../types';

export const LANGUAGES: Record<LanguageKey, LanguageData> = {
  hinglish: {
    key: 'hinglish',
    label: 'Roman Urdu / Hinglish',
    nativeLabel: 'Hinglish (Roman)',
    flagIcon: '🇮🇳',
    tagline: 'Mera Bharat Mahan - 15 August 2026',
    happyIndependence: 'Swatantrata Diwas Ki Hardik Shubhkamnayein!',
    yearCelebration: '15 August 2026 - 80th Independence Day',
    senderPrefix: '',
    senderSuffix: 'ki taraf se aapko aur aapke poore parivar ko 15 August ki dheron badhaiyan!',
    enterNamePlaceholder: 'Apna Naam Yahan Likhein...',
    createWishBtn: 'Apna Special Wish Banayein ✨',
    shareOnWhatsAppBtn: 'WhatsApp Par Sabhi Doston Ko Bhejein 🚀',
    shareOnTelegramBtn: 'Telegram Par Bhejein',
    shareOnFacebookBtn: 'Facebook Par Share Karein',
    copyLinkBtn: 'Link Copy Karein 📋',
    surpriseGiftTitle: 'Aapke Liye Ek Khas Tiranga Surprise Gift Hai! 🎁',
    tapToOpenText: 'Tirange Par Touch Karke Surprise Kholein 🇮🇳',
    anthemTitle: 'Rashtriya Gaan (National Anthem) 🎵',
    pledgeTitle: 'Tiranga Rashtriya Sankalp 2026 🇮🇳',
    pledgeText: 'Main ek garvmayee Bharatiya hone ke naate shapath leta hoon ki main apne desh ki ekta, akhandata aur unnati ke liye sadaiv samarpit rahoonga. Jai Hind!',
    pledgeActionBtn: 'Tirange Ko Salute & Sankalp Karein 🫡',
    pledgeDoneText: 'Aapne Tirange Ko Salute Kiya! Bharat Mata Ki Jai! 🎉',
    quotesTitle: 'Deshbhakti Shayari & Anmol Vachan',
    quotesSubtitle: 'Veer Shaheedon Ko Naman & Prernadayak Sandesh',
    frameTitle: 'Apni Tiranga DP / Photo Frame Banayein 📸',
    frameSubtitle: '15 August ke liye apni photo par tricolor badge lagayein aur WhatsApp DP set karein',
    uploadPhotoBtn: 'Photo Select Karein',
    downloadFrameBtn: 'HD DP Download Karein 📥',
    countdownDays: 'Din',
    countdownHours: 'Ghante',
    countdownMinutes: 'Minute',
    countdownSeconds: 'Second',
    shayariList: [
      {
        quote: 'Kuch nasha Tirange ki aaan ka hai, kuch nasha matribhoomi ki shaan ka hai. Hum lehrayenge har jagah yeh Tiranga, nasha yeh Hindustan ke samman ka hai!',
        author: 'Deshbhakti Sandesh'
      },
      {
        quote: 'Sarfaroshi ki tamanna ab hamare dil mein hai, dekhna hai zor kitna baazu-e-qaatil mein hai!',
        author: 'Ram Prasad Bismil'
      },
      {
        quote: 'Sare jahan se achha Hindustan hamara, hum bulbulein hain iski yeh gulsitan hamara!',
        author: 'Allama Iqbal'
      },
      {
        quote: 'Inquilab Zindabad! Desh par mar mitne walon ka karwan kabhi rukta nahi.',
        author: 'Shaheed Bhagat Singh'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15 AUGUST 2026 SURPRISE GIFT* 🎁\n\n*${sender}* ne aapke liye ek bahut hi pyara aur khas 15 August Tiranga Surprise Sandesh bheja hai!\n\n👇 *Neeche di gayi blue link par click karke dekhein:* 👇\n${appUrl}\n\n_Ise apne sabhi doston aur family groups mein zaroor share karein! Vande Mataram!_ 🇮🇳`
  },
  hindi: {
    key: 'hindi',
    label: 'Hindi',
    nativeLabel: 'हिन्दी',
    flagIcon: '🇮🇳',
    tagline: 'मेरा भारत महान - 15 अगस्त 2026',
    happyIndependence: 'स्वतंत्रता दिवस की हार्दिक शुभकामनाएं!',
    yearCelebration: '15 अगस्त 2026 - 80वाँ स्वतंत्रता दिवस',
    senderPrefix: '',
    senderSuffix: 'की तरफ से आपको और आपके पूरे परिवार को 15 अगस्त की ढेरों शुभकामनाएं!',
    enterNamePlaceholder: 'अपना नाम यहाँ लिखें...',
    createWishBtn: 'अपनी स्पेशल बधाई बनाएं ✨',
    shareOnWhatsAppBtn: 'व्हाट्सएप पर सभी को भेजें 🚀',
    shareOnTelegramBtn: 'टेलीग्राम पर भेजें',
    shareOnFacebookBtn: 'फेसबुक पर शेयर करें',
    copyLinkBtn: 'लिंक कॉपी करें 📋',
    surpriseGiftTitle: 'आपके लिए एक खास तिरंगा सरप्राइज गिफ्ट है! 🎁',
    tapToOpenText: 'तिरंगे पर टच करके सरप्राइज खोलें 🇮🇳',
    anthemTitle: 'राष्ट्रगान - जन गण मन 🎵',
    pledgeTitle: 'तिरंगा राष्ट्रीय संकल्प 2026 🇮🇳',
    pledgeText: 'मैं एक स्वाभिमानी भारतीय होने के नाते शपथ लेता/लेती हूँ कि देश की अखंडता, स्वच्छता, विकास और एकता के लिए सदैव समर्पित रहूँगा/रहूँगी। जय हिन्द!',
    pledgeActionBtn: 'तिरंगे को सैल्यूट व संकल्प करें 🫡',
    pledgeDoneText: 'आपने तिरंगे को सैल्यूट किया! भारत माता की जय! 🎉',
    quotesTitle: 'देशभक्ति शायरी एवं अमर विचार',
    quotesSubtitle: 'वीर शहीदों के बलिदान को शत-शत नमन',
    frameTitle: 'अपनी तिरंगा DP / फोटो फ्रेम बनाएं 📸',
    frameSubtitle: '15 अगस्त के लिए अपनी फोटो पर तिरंगा बैज लगाएं और स्टेटस पर लगाएं',
    uploadPhotoBtn: 'फोटो चुनें',
    downloadFrameBtn: 'HD DP डाउनलोड करें 📥',
    countdownDays: 'दिन',
    countdownHours: 'घंटे',
    countdownMinutes: 'मिनट',
    countdownSeconds: 'सेकंड',
    shayariList: [
      {
        quote: 'कुछ नशा तिरंगे की आन का है, कुछ नशा मातृभूमि की शान का है। हम लहराएंगे हर जगह ये तिरंगा, नशा ये हिंदुस्तान के सम्मान का है!',
        author: 'देशभक्ति शायरी'
      },
      {
        quote: 'दे सलामी इस तिरंगे को जिससे तेरी शान है, सर हमेशा ऊँचा रखना इसका जब तक दिल में जान है!',
        author: 'अमर संदेश'
      },
      {
        quote: 'सारे जहाँ से अच्छा हिन्दोस्तां हमारा, हम बुलबुलें हैं इसकी ये गुलसितां हमारा!',
        author: 'मोहम्मद इक़बाल'
      },
      {
        quote: 'इंक़लाब ज़िन्दाबाद! साम्राज्यवाद का नाश हो! भारत माता की जय!',
        author: 'शहीद भगत सिंह'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15 अगस्त 2026 का स्पेशल सरप्राइज* 🎁\n\n*${sender}* ने आपके लिए एक बहुत ही सुंदर और जादुई 15 अगस्त तिरंगा बधाई संदेश भेजा है!\n\n👇 *नीचे नीले लिंक पर क्लिक करके अभी देखें:* 👇\n${appUrl}\n\n_जय हिन्द! वन्दे मातरम्! इसे तुरंत सभी दोस्तों और व्हाट्सएप ग्रुप में भेजें!_ 🇮🇳`
  },
  english: {
    key: 'english',
    label: 'English',
    nativeLabel: 'English',
    flagIcon: '🇮🇳',
    tagline: 'Proud to be Indian - 15 August 2026',
    happyIndependence: 'Happy 80th Independence Day 2026!',
    yearCelebration: '15th August 2026 - Glory of Tiranga',
    senderPrefix: 'Special greetings from ',
    senderSuffix: ' wishing you and your loved ones a joyful, proud Independence Day!',
    enterNamePlaceholder: 'Enter your name here...',
    createWishBtn: 'Create Your Personal Wish ✨',
    shareOnWhatsAppBtn: 'Send on WhatsApp to All Friends 🚀',
    shareOnTelegramBtn: 'Share on Telegram',
    shareOnFacebookBtn: 'Share on Facebook',
    copyLinkBtn: 'Copy Shareable Link 📋',
    surpriseGiftTitle: 'You have received a special Independence Day surprise! 🎁',
    tapToOpenText: 'Touch the Tiranga Flag to Open the Surprise 🇮🇳',
    anthemTitle: 'National Anthem - Jana Gana Mana 🎵',
    pledgeTitle: 'National Tricolor Pledge 2026 🇮🇳',
    pledgeText: 'India is my country and all Indians are my brothers and sisters. I pledge my unyielding devotion to the unity, progress, and sovereignty of our nation. Jai Hind!',
    pledgeActionBtn: 'Salute the Tricolor & Take Pledge 🫡',
    pledgeDoneText: 'You saluted the National Flag! Bharat Mata Ki Jai! 🎉',
    quotesTitle: 'Patriotic Quotes & Immortal Words',
    quotesSubtitle: 'Honoring the heroes of our freedom struggle',
    frameTitle: 'Create Your Independence Day DP Frame 📸',
    frameSubtitle: 'Upload your photo, apply patriotic tricolor borders, and set as WhatsApp DP',
    uploadPhotoBtn: 'Upload Photo',
    downloadFrameBtn: 'Download HD Frame 📥',
    countdownDays: 'Days',
    countdownHours: 'Hours',
    countdownMinutes: 'Mins',
    countdownSeconds: 'Secs',
    shayariList: [
      {
        quote: 'Freedom is not given, it is taken. At the stroke of the midnight hour, when the world sleeps, India will awake to life and freedom.',
        author: 'Netaji Subhas Chandra Bose'
      },
      {
        quote: 'Let new India arise out of peasants cottage, grasping the plough, out of huts, cobbler and sweeper.',
        author: 'Swami Vivekananda'
      },
      {
        quote: 'Better to remain silent and be thoughtful than speak without purpose for our motherland.',
        author: 'APJ Abdul Kalam'
      },
      {
        quote: 'Citizenship consists in the service of the country. Long live free India!',
        author: 'Jawaharlal Nehru'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15th AUGUST 2026 SURPRISE WISH* 🎁\n\n*${sender}* has sent you a breathtaking 15th August Independence Day musical greeting card!\n\n👇 *Click the blue link below to open your gift:* 👇\n${appUrl}\n\n_Share with your friends and family groups to celebrate together! Jai Hind!_ 🇮🇳`
  },
  urdu: {
    key: 'urdu',
    label: 'Urdu',
    nativeLabel: 'اردو',
    flagIcon: '🇮🇳',
    tagline: 'سارے جہاں سے اچھا ہندوستاں ہمارا - 15 اگست 2026',
    happyIndependence: 'یومِ آزادی مبارک ہو!',
    yearCelebration: '15 اگست 2026 - 80 واں یومِ آزادی',
    senderPrefix: '',
    senderSuffix: 'کی جانب سے آپ کو اور آپ کے اہل خانہ کو یوم آزادی کی دلی مبارکباد!',
    enterNamePlaceholder: 'اپنا نام یہاں درج کریں...',
    createWishBtn: 'اپنا خصوصی تہنیتی پیغام بنائیں ✨',
    shareOnWhatsAppBtn: 'واٹس ایپ پر تمام دوستوں کو بھیجیں 🚀',
    shareOnTelegramBtn: 'ٹیلیگرام پر شیئر کریں',
    shareOnFacebookBtn: 'فیس بک پر شیئر کریں',
    copyLinkBtn: 'لنک کاپی کریں 📋',
    surpriseGiftTitle: 'آپ کے لیے ایک خوبصورت ترنگا سرپرائز گفٹ! 🎁',
    tapToOpenText: 'سرپرائز کھولنے کے لیے ترنگے کو چھوئیں 🇮🇳',
    anthemTitle: 'قومی ترانہ - جن گن من 🎵',
    pledgeTitle: 'قومی عہد 2026 🇮🇳',
    pledgeText: 'ہم اپنے وطن عزیز بھارت کی سالمیت، اخوت، اتحاد اور ترقی کے لیے ہر لمحہ پرعزم رہنے کا عہد کرتے ہیں۔ جے ہند!',
    pledgeActionBtn: 'ترنگے کو سلامی دیں اور عہد کریں 🫡',
    pledgeDoneText: 'آپ نے قومی پرچم کو سلامی دی! جے ہند! 🎉',
    quotesTitle: 'حب الوطنی کے اشعار اور زریں اقوال',
    quotesSubtitle: 'شہداء کے نام خراج عقیدت',
    frameTitle: 'اپنی ترنگا ڈی پی / فوٹو فریم بنائیں 📸',
    frameSubtitle: '15 اگست کے لیے اپنی تصویر پر حب الوطنی کا فریم لگائیں اور ڈی پی بنائیں',
    uploadPhotoBtn: 'تصویر منتخب کریں',
    downloadFrameBtn: 'ایچ ڈی ڈی پی ڈاؤن لوڈ کریں 📥',
    countdownDays: 'دن',
    countdownHours: 'گھنٹے',
    countdownMinutes: 'منٹ',
    countdownSeconds: 'سیکنڈ',
    shayariList: [
      {
        quote: 'سارے جہاں سے اچھا ہندوستاں ہمارا، ہم بلبلیں ہیں اس کی یہ گلستاں ہمارا!',
        author: 'علامہ محمد اقبال'
      },
      {
        quote: 'لہو دے کر ترنگے کی بلندی کو سجایا ہے، یہ آزادی یونہی ہم نے نہیں پائی، بہت کچھ لٹایا ہے!',
        author: 'شاعر مشرق'
      },
      {
        quote: 'سرفروشی کی تمنا اب ہمارے دل میں ہے، دیکھنا ہے زور کتنا بازوئے قاتل میں ہے!',
        author: 'رام پرساد بسمل'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15 اگست 2026 کا خوبصورت تحفہ* 🎁\n\n*${sender}* نے آپ کے لیے 15 اگست یوم آزادی کا دلکش سرپرائز تہنیتی کارڈ بھیجا ہے!\n\n👇 *اپنا تحفہ دیکھنے کے لیے نیچے دیے گئے لنک پر کلک کریں:* 👇\n${appUrl}\n\n_اسے اپنے تمام دوستوں اور گروپس میں ضرور شیئر کریں!_ 🇮🇳`
  },
  telugu: {
    key: 'telugu',
    label: 'Telugu',
    nativeLabel: 'తెలుగు',
    flagIcon: '🇮🇳',
    tagline: 'నా భారతదేశం మహోన్నతం - 15 ఆగస్టు 2026',
    happyIndependence: 'స్వాతంత్ర్య దినోత్సవ శుభాకాంక్షలు!',
    yearCelebration: '15 ఆగస్టు 2026 - 80వ స్వాతంత్ర్య దినోత్సవం',
    senderPrefix: '',
    senderSuffix: 'తరఫున మీకు మరియు మీ కుటుంబ సభ్యులందరికీ స్వాతంత్ర్య దినోత్సవ శుభాకాంక్షలు!',
    enterNamePlaceholder: 'మీ పేరు ఇక్కడ రాయండి...',
    createWishBtn: 'మీ స్పెషల్ శుభాకాంక్షలు సృష్టించండి ✨',
    shareOnWhatsAppBtn: 'వాట్సాప్‌లో అందరికీ పంపండి 🚀',
    shareOnTelegramBtn: 'టెలిగ్రామ్‌లో పంపండి',
    shareOnFacebookBtn: 'ఫేస్‌బుక్‌లో షేర్ చేయండి',
    copyLinkBtn: 'లింక్ కాపీ చేయండి 📋',
    surpriseGiftTitle: 'మీ కోసం ప్రత్యేక త్రివర్ణ పతాక సర్ప్రైజ్ గిఫ్ట్! 🎁',
    tapToOpenText: 'సర్ప్రైజ్ తెరవడానికి జెండాను తాకండి 🇮🇳',
    anthemTitle: 'జాతీయ గీతం - జన గణ మన 🎵',
    pledgeTitle: 'జాతీయ ప్రతిజ్ఞ 2026 🇮🇳',
    pledgeText: 'భారతదేశం నా మాతృభూమి. భారతీయులందరూ నా సహోదరులు. దేశ రక్షణ, ప్రగతి మరియు సమగ్రత కోసం నిరంతరం శ్రమిస్తాను. జై హింద్!',
    pledgeActionBtn: 'జెండాకు సెల్యూట్ చేసి ప్రతిజ్ఞ చేయండి 🫡',
    pledgeDoneText: 'మీరు జాతీయ జెండాకు సెల్యూట్ చేశారు! జై హింద్! 🎉',
    quotesTitle: 'దేశభక్తి సూక్తులు & అమర సందేశాలు',
    quotesSubtitle: 'స్వాతంత్ర్య సమరయోధులకు ఘన నివాళి',
    frameTitle: 'మీ త్రివర్ణ DP / ఫోటో ఫ్రేమ్ తయారుచేయండి 📸',
    frameSubtitle: '15 ఆగస్టు కోసం మీ ఫోటోతో దేశభక్తి బ్యాడ్జ్ తయారు చేసి వాట్సాప్ DPగా పెట్టుకోండి',
    uploadPhotoBtn: 'ఫోటో ఎంచుకోండి',
    downloadFrameBtn: 'HD DP డౌన్‌లోడ్ చేయండి 📥',
    countdownDays: 'రోజులు',
    countdownHours: 'గంటలు',
    countdownMinutes: 'నిమిషాలు',
    countdownSeconds: 'సెకన్లు',
    shayariList: [
      {
        quote: 'దేశమును ప్రేమించుమన్నా, మంచి అన్నది పెంచుమన్నా, వట్టి మాటలు కట్టిపెట్టోయ్, గట్టిమేల్ తలపెట్టవోయ్!',
        author: 'గురజాడ అప్పారావు'
      },
      {
        quote: 'స్వరాజ్యం నా జన్మహక్కు, దానిని నేను పొంది తీరుతాను!',
        author: 'బాలగంగాధర తిలక్'
      },
      {
        quote: 'భారత మాత ముద్దుబిడ్డలమైన మనమంతా కలిసి దేశ సమగ్రతను కాపాడుకుందాం!',
        author: 'జాతీయ సందేశం'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15 ఆగస్టు 2026 స్పెషల్ సర్ప్రైజ్ గిఫ్ట్* 🎁\n\n*${sender}* మీ కోసం ఒక అందమైన 15 ఆగస్టు స్వాతంత్ర్య దినోత్సవ శుభాకాంక్షల సర్ప్రైజ్ కార్డు పంపారు!\n\n👇 *కింది నీలిరంగు లింక్‌పై క్లిక్ చేసి చూడండి:* 👇\n${appUrl}\n\n_మీ స్నేహితులు మరియు వాట్సాప్ గ్రూపులందరికీ వెంటనే షేర్ చేయండి! జై హింద్!_ 🇮🇳`
  },
  tamil: {
    key: 'tamil',
    label: 'Tamil',
    nativeLabel: 'தமிழ்',
    flagIcon: '🇮🇳',
    tagline: 'வந்தே மாதரம் - 15 ஆகஸ்ட் 2026',
    happyIndependence: 'சுதந்திர தின நல்வாழ்த்துகள்!',
    yearCelebration: '15 ஆகஸ்ட் 2026 - 80வது சுதந்திர தினம்',
    senderPrefix: '',
    senderSuffix: 'சார்பாக உங்களுக்கும் உங்கள் குடும்பத்தினருக்கும் இனிய சுதந்திர தின நல்வாழ்த்துகள்!',
    enterNamePlaceholder: 'உங்கள் பெயரை இங்கே உள்ளிடவும்...',
    createWishBtn: 'உங்கள் சிறப்பு வாழ்த்தை உருவாக்கவும் ✨',
    shareOnWhatsAppBtn: 'வாட்ஸ்அப்பில் அனைவருக்கும் அனுப்பவும் 🚀',
    shareOnTelegramBtn: 'டெலிகிராமில் பகிரவும்',
    shareOnFacebookBtn: 'பேஸ்புக்கில் பகிரவும்',
    copyLinkBtn: 'இணைப்பை நகலெடுக்கவும் 📋',
    surpriseGiftTitle: 'உங்களுக்காக ஒரு பிரத்யேக மூவர்ண சர்ப்ரைஸ் பரிசு! 🎁',
    tapToOpenText: 'பரிசைத் திறக்க தேசியக் கொடியைத் தொடவும் 🇮🇳',
    anthemTitle: 'தேசிய கீதம் - ஜன கண மன 🎵',
    pledgeTitle: 'தேசிய உறுதிமொழி 2026 🇮🇳',
    pledgeText: 'இந்தியா எனது தாய்நாடு. இந்தியர்கள் அனைவரும் எனது சகோதர சகோதரிகள். நாட்டின் ஒற்றுமைக்கும் வளர்ச்சிக்கும் என்றும் பாடுபடுவேன். ஜெய் ஹிந்த்!',
    pledgeActionBtn: 'கொடிக்கு சல்யூட் செய்து உறுதிமொழி எடுக்கவும் 🫡',
    pledgeDoneText: 'நீங்கள் தேசியக் கொடிக்கு சல்யூட் செய்துள்ளீர்கள்! ஜெய் ஹிந்த்! 🎉',
    quotesTitle: 'தேசபக்தி பொன்மொழிகள் & கவிதைகள்',
    quotesSubtitle: 'விடுதலை வீரர்களுக்கு வீரவணக்கம்',
    frameTitle: 'மூவர்ண DP / புகைப்பட சட்டகம் உருவாக்கவும் 📸',
    frameSubtitle: '15 ஆகஸ்ட் கொண்டாட்டத்திற்கு உங்கள் புகைப்படத்துடன் தேசியக் கொடி DP அமைக்கவும்',
    uploadPhotoBtn: 'புகைப்படம் தேர்வு செய்யவும்',
    downloadFrameBtn: 'HD DP பதிவிறக்கவும் 📥',
    countdownDays: 'நாட்கள்',
    countdownHours: 'மணிகள்',
    countdownMinutes: 'நிமிடங்கள்',
    countdownSeconds: 'வினாடிகள்',
    shayariList: [
      {
        quote: 'என்று தணியும் இந்த சுதந்திர தாகம்? என்று மடியும் எங்கள் அடிமையின் மோகம்?',
        author: 'மகாகவி பாரதியார்'
      },
      {
        quote: 'தாயின் மணிக்கொடி பாரீர் - அதைத் தாழ்ந்து பணிந்து புகழ்ந்திட வாரீர்!',
        author: 'பாரதியார்'
      },
      {
        quote: 'ஒற்றுமையே நம் வலிமை, பாரத தேசமே நம் அடையாளம்!',
        author: 'அமரர் சிந்தனை'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15 ஆகஸ்ட் 2026 சிறப்பு சர்ப்ரைஸ் பரிசு* 🎁\n\n*${sender}* உங்களுக்காக ஒரு அற்புதமான 15 ஆகஸ்ட் சுதந்திர தின வாழ்த்து அட்டையை அனுப்பியுள்ளார்!\n\n👇 *கீழே உள்ள நீல இணைப்பை கிளிக் செய்து பார்க்கவும்:* 👇\n${appUrl}\n\n_இதை உங்கள் அனைத்து வாட்ஸ்அப் நண்பர்கள் மற்றும் குழுக்களுடன் பகிருங்கள்! வந்தே மாதரம்!_ 🇮🇳`
  },
  bengali: {
    key: 'bengali',
    label: 'Bengali',
    nativeLabel: 'বাংলা',
    flagIcon: '🇮🇳',
    tagline: 'বন্দে মাতরম্ - ১৫ আগস্ট ২০২৬',
    happyIndependence: 'স্বাধীনতা দিবসের আন্তরিক শুভেচ্ছা!',
    yearCelebration: '১৫ই আগস্ট ২০২৬ - ৮০তম স্বাধীনতা দিবস',
    senderPrefix: '',
    senderSuffix: '-এর পক্ষ থেকে আপনাকে ও আপনার পরিবারকে স্বাধীনতা দিবসের অফুরন্ত শুভেচ্ছা!',
    enterNamePlaceholder: 'আপনার নাম লিখুন...',
    createWishBtn: 'নিজের স্পেশাল শুভেচ্ছা তৈরি করুন ✨',
    shareOnWhatsAppBtn: 'হোয়াটসঅ্যাপে সবাইকে পাঠান 🚀',
    shareOnTelegramBtn: 'টেলিগ্রামে পাঠান',
    shareOnFacebookBtn: 'ফেসবুকে শেয়ার করুন',
    copyLinkBtn: 'লিঙ্ক কপি করুন 📋',
    surpriseGiftTitle: 'আপনার জন্য একটি বিশেষ তিরঙ্গা সারপ্রাইজ উপহার! 🎁',
    tapToOpenText: 'উপহার খুলতে জাতীয় পতাকায় স্পর্শ করুন 🇮🇳',
    anthemTitle: 'জাতীয় সঙ্গীত - জনগণমন-অধিনায়ক 🎵',
    pledgeTitle: 'জাতীয় সংকল্প ২০২৬ 🇮🇳',
    pledgeText: 'ভারত আমার জন্মভূমি। দেশের ঐক্য, সংহতি ও সমৃদ্ধির জন্য আমি আজীবন নিবেদিত থাকব। জয় হিন্দ!',
    pledgeActionBtn: 'পতাকাকে স্যালুট ও সংকল্প গ্রহণ করুন 🫡',
    pledgeDoneText: 'আপনি জাতীয় পতাকাকে স্যালুট জানিয়েছেন! জয় হিন্দ! 🎉',
    quotesTitle: 'দেশপ্রেমের অমর বাণী ও স্লোগান',
    quotesSubtitle: 'বীর শহীদদের প্রতি বিনম্র শ্রদ্ধাঞ্জলি',
    frameTitle: 'নিজের তিরঙ্গা DP / ফটো ফ্রেম তৈরি করুন 📸',
    frameSubtitle: '১৫ আগস্টের জন্য আপনার ছবিতে তিরঙ্গা ব্যাজ যুক্ত করে হোয়াটসঅ্যাপ ডিপি তৈরি করুন',
    uploadPhotoBtn: 'ছবি নির্বাচন করুন',
    downloadFrameBtn: 'HD DP ডাউনলোড করুন 📥',
    countdownDays: 'দিন',
    countdownHours: 'ঘণ্টা',
    countdownMinutes: 'মিনিট',
    countdownSeconds: 'সেকেন্ড',
    shayariList: [
      {
        quote: 'তোমরা আমাকে রক্ত দাও, আমি তোমাদের স্বাধীনতা দেব!',
        author: 'নেতাজি সুভাষচন্দ্র বসু'
      },
      {
        quote: 'চিত্ত যেথা ভয়শূন্য, উচ্চ যেথা শির, জ্ঞান যেথা মুক্ত, যেথা গৃহের প্রাচীর!',
        author: 'রবীন্দ্রনাথ ঠাকুর'
      },
      {
        quote: 'বল বীর, বল উন্নত মম শির! শির নেহারি আমারি নতশির ওই শিখর হিমাদ্রির!',
        author: 'কাজী নজরুল ইসলাম'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *১৫ই আগস্ট ২০২৬ সারপ্রাইজ উপহার* 🎁\n\n*${sender}* আপনার জন্য একটি অত্যন্ত সুন্দর ১৫ই আগস্ট স্বাধীনতা দিবসের শুভেচ্ছা কার্ড পাঠিয়েছেন!\n\n👇 *নিচের লিঙ্কে ক্লিক করে এখুনি দেখুন:* 👇\n${appUrl}\n\n_আপনার সকল বন্ধুবান্ধব ও গ্রুপে অবশ্যই শেয়ার করুন! জয় হিন্দ!_ 🇮🇳`
  },
  marathi: {
    key: 'marathi',
    label: 'Marathi',
    nativeLabel: 'मराठी',
    flagIcon: '🇮🇳',
    tagline: 'जय हिंद जय महाराष्ट्र - १५ ऑगस्ट २०२६',
    happyIndependence: 'स्वातंत्र्य दिनाच्या हार्दिक शुभेच्छा!',
    yearCelebration: '१५ ऑगस्ट २०२६ - ८० वा स्वातंत्र्य दिन',
    senderPrefix: '',
    senderSuffix: 'यांच्याकडून आपणास व आपल्या परिवारास स्वातंत्र्य दिनाच्या मनःपूर्वक शुभेच्छा!',
    enterNamePlaceholder: 'तुमचे नाव येथे लिहा...',
    createWishBtn: 'तुमची खास शुभेच्छा तयार करा ✨',
    shareOnWhatsAppBtn: 'व्हॉट्सअ‍ॅपवर सर्वांना पाठवा 🚀',
    shareOnTelegramBtn: 'टेलिग्रामवर पाठवा',
    shareOnFacebookBtn: 'फेसबुकवर शेअर करा',
    copyLinkBtn: 'लिंक कॉपी करा 📋',
    surpriseGiftTitle: 'तुमच्यासाठी एक खास तिरंगा सरप्राईज गिफ्ट! 🎁',
    tapToOpenText: 'सरप्राईज उघडण्यासाठी तिरंग्यावर स्पर्श करा 🇮🇳',
    anthemTitle: 'राष्ट्रगीत - जन गण मन 🎵',
    pledgeTitle: 'तिरंगा राष्ट्रीय प्रतिज्ञा २०२६ 🇮🇳',
    pledgeText: 'भारत माझा देश आहे. सर्व भारतीय माझे बांधव आहेत. देशाच्या एकात्मतेसाठी व प्रगतीसाठी मी सदैव तत्पर राहीन. जय हिंद!',
    pledgeActionBtn: 'तिरंग्याला सॅल्यूट व प्रतिज्ञा करा 🫡',
    pledgeDoneText: 'तुम्ही राष्ट्रध्वजाला सॅल्यूट केला! जय हिंद! 🎉',
    quotesTitle: 'देशभक्तीपर विचार आणि शायरी',
    quotesSubtitle: 'क्रांतिकारकांच्या बलिदानाला कोटी कोटी प्रणाम',
    frameTitle: 'तुमची तिरंगा DP / फोटो फ्रेम बनवा 📸',
    frameSubtitle: '१५ ऑगस्टसाठी तुमच्या फोटोवर तिरंगा फ्रेम लावा आणि डीपी सेट करा',
    uploadPhotoBtn: 'फोटो निवडा',
    downloadFrameBtn: 'HD DP डाऊनलोड करा 📥',
    countdownDays: 'दिवस',
    countdownHours: 'तास',
    countdownMinutes: 'मिनिटे',
    countdownSeconds: 'सेकंद',
    shayariList: [
      {
        quote: 'स्वराज्य हा माझा जन्मसिद्ध हक्क आहे आणि तो मी मिळवणारच!',
        author: 'लोकमान्य बाळ गंगाधर टिळक'
      },
      {
        quote: 'उत्सव तीन रंगांचा, आभाळी आज सजला, नतमस्तक मी त्या चरणी, ज्यांनी भारत देश घडवला!',
        author: 'देशभक्ती कविता'
      },
      {
        quote: 'जरी संकटे आली कितीही, तिरंगा सदा डौलाने फडकत राहील!',
        author: 'अमर विचार'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *१५ ऑगस्ट २०२६ चे खास सरप्राईज गिफ्ट* 🎁\n\n*${sender}* यांनी तुमच्यासाठी स्वातंत्र्य दिनाचे एक अतिशय सुंदर सरप्राईज कार्ड पाठवले आहे!\n\n👇 *खालील लिंकवर क्लिक करून आत्ताच पहा:* 👇\n${appUrl}\n\n_हे तुमच्या सर्व मित्र आणि ग्रुप्समध्ये नक्की शेअर करा! भारत माता की जय!_ 🇮🇳`
  },
  gujarati: {
    key: 'gujarati',
    label: 'Gujarati',
    nativeLabel: 'ગુજરાતી',
    flagIcon: '🇮🇳',
    tagline: 'મારું ભારત મહાન - ૧૫ ઓગસ્ટ ૨૦૨૬',
    happyIndependence: 'સ્વતંત્રતા દિવસની હાર્દિક શુભેચ્છાઓ!',
    yearCelebration: '૧૫ ઓગસ્ટ ૨૦૨૬ - ૮૦મો સ્વતંત્રતા દિવસ',
    senderPrefix: '',
    senderSuffix: 'તરફથી તમને અને તમારા સમગ્ર પરિવારને સ્વતંત્રતા દિવસની ખૂબ ખૂબ શુભેચ્છાઓ!',
    enterNamePlaceholder: 'તમારું નામ અહીં લખો...',
    createWishBtn: 'તમારી સ્પેશિયલ શુભેચ્છા બનાવો ✨',
    shareOnWhatsAppBtn: 'વોટ્સએપ પર બધાને મોકલો 🚀',
    shareOnTelegramBtn: 'ટેલિગ્રામ પર મોકલો',
    shareOnFacebookBtn: 'ફેસબુક પર શેર કરો',
    copyLinkBtn: 'લિંક કોપી કરો 📋',
    surpriseGiftTitle: 'તમારા માટે ખાસ ત્રિરંગા સરપ્રાઈઝ ગિફ્ટ! 🎁',
    tapToOpenText: 'સરપ્રાઈઝ ખોલવા ત્રિરંગા પર ટચ કરો 🇮🇳',
    anthemTitle: 'રાષ્ટ્રગીત - જન ગણ મન 🎵',
    pledgeTitle: 'રાષ્ટ્રીય પ્રતિજ્ઞા ૨૦૨૬ 🇮🇳',
    pledgeText: 'ભારત મારો દેશ છે. બધા ભારતીયો મારા ભાઈ-બહેનો છે. દેશની એકતા અને સમૃદ્ધિ માટે હું સદાય સમર્પિત રહીશ. જય હિન્દ!',
    pledgeActionBtn: 'તિરંગાને સલામી અને પ્રતિજ્ઞા લો 🫡',
    pledgeDoneText: 'તમે રાષ્ટ્રધ્વજને સલામી આપી! વંદે માતરમ્! 🎉',
    quotesTitle: 'દેશભક્તિ સુવિચારો અને શાયરી',
    quotesSubtitle: 'વીર શહીદોને કોટિ કોટિ વંદન',
    frameTitle: 'તમારી ત્રિરંગા DP / ફોટો ફ્રેમ બનાવો 📸',
    frameSubtitle: '૧૫ ઓગસ્ટ માટે તમારા ફોટો સાથે દેશભક્તિ ફ્રેમ બનાવી વોટ્સએપ ડીપી લગાવો',
    uploadPhotoBtn: 'ફોટો પસંદ કરો',
    downloadFrameBtn: 'HD DP ડાઉનલોડ કરો 📥',
    countdownDays: 'દિવસ',
    countdownHours: 'કલાક',
    countdownMinutes: 'મિનિટ',
    countdownSeconds: 'સેકન્ડ',
    shayariList: [
      {
        quote: 'જ્યાં સુધી દેશ માટે સમર્પણ છે, ત્યાં સુધી ભારત વિશ્વગુરુ રહેશે!',
        author: 'મહાત્મા ગાંધી'
      },
      {
        quote: 'ત્રિરંગો આપણી શાન છે, ભારત દેશ આપણો પ્રાણ છે!',
        author: 'દેશભક્તિ સંદેશ'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *૧૫ ઓગસ્ટ ૨૦૨૬ સ્પેશિયલ સરપ્રાઈઝ* 🎁\n\n*${sender}* એ તમારા માટે એક સુંદર ૧૫ ઓગસ્ટ સ્વાતંત્ર્ય પર્વનું સરપ્રાઈઝ કાર્ડ મોકલ્યું છે!\n\n👇 *નીચેની લિંક પર ક્લિક કરીને જુઓ:* 👇\n${appUrl}\n\n_તમારા તમામ મિત્રો અને ગ્રુપોમાં જરૂર શેર કરો! જય હિન્દ!_ 🇮🇳`
  },
  kannada: {
    key: 'kannada',
    label: 'Kannada',
    nativeLabel: 'ಕನ್ನಡ',
    flagIcon: '🇮🇳',
    tagline: 'ನನ್ನ ಭಾರತ ಮಹಾನ್ - 15 ಆಗಸ್ಟ್ 2026',
    happyIndependence: 'ಸ್ವಾತಂತ್ರ್ಯ ದಿನಾಚರಣೆಯ ಹಾರ್ದಿಕ ಶುಭಾಶಯಗಳು!',
    yearCelebration: '15 ಆಗಸ್ಟ್ 2026 - 80ನೇ ಸ್ವಾತಂತ್ರ್ಯ ದಿನಾಚರಣೆ',
    senderPrefix: '',
    senderSuffix: 'ಅವರ ಕಡೆಯಿಂದ ನಿಮಗೂ ಮತ್ತು ನಿಮ್ಮ ಕುಟುಂಬದವರಿಗೂ ಸ್ವಾತಂತ್ರ್ಯ ದಿನದ ಶುಭಾಶಯಗಳು!',
    enterNamePlaceholder: 'ನಿಮ್ಮ ಹೆಸರನ್ನು ಇಲ್ಲಿ ಬರೆಯಿರಿ...',
    createWishBtn: 'ನಿಮ್ಮ ವಿಶೇಷ ಶುಭಾಶಯ ರಚಿಸಿ ✨',
    shareOnWhatsAppBtn: 'ವಾಟ್ಸಾಪ್‌ನಲ್ಲಿ ಎಲ್ಲರಿಗೂ ಕಳುಹಿಸಿ 🚀',
    shareOnTelegramBtn: 'ಟೆಲಿಗ್ರಾಂನಲ್ಲಿ ಹಂಚಿಕೊಳ್ಳಿ',
    shareOnFacebookBtn: 'ಫೇಸ್‌ಬುಕ್‌ನಲ್ಲಿ ಹಂಚಿಕೊಳ್ಳಿ',
    copyLinkBtn: 'ಲಿಂಕ್ ಕಾಪಿ ಮಾಡಿ 📋',
    surpriseGiftTitle: 'ನಿಮಗಾಗಿ ವಿಶೇಷ ತ್ರಿವರ್ಣ ಧ್ವಜದ ಸರ್ಪ್ರೈಸ್ ಗಿಫ್ಟ್! 🎁',
    tapToOpenText: 'ಸರ್ಪ್ರೈಸ್ ತೆರೆಯಲು ಧ್ವಜವನ್ನು ಸ್ಪರ್ಶಿಸಿ 🇮🇳',
    anthemTitle: 'ರಾಷ್ಟ್ರಗೀತೆ - ಜನ ಗಣ ಮನ 🎵',
    pledgeTitle: 'ರಾಷ್ಟ್ರೀಯ ಪ್ರತಿಜ್ಞೆ 2026 🇮🇳',
    pledgeText: 'ಭಾರತ ನನ್ನ ದೇಶ. ಎಲ್ಲ ಭಾರತೀಯರು ನನ್ನ ಸಹೋದರ ಸಹೋದರಿಯರು. ದೇಶದ ಏಕತೆ ಮತ್ತು ಪ್ರಗತಿಗಾಗಿ ನಾನು ಸದಾ ಬದ್ಧನಾಗಿರುತ್ತೇನೆ. ಜೈ ಹಿಂದ್!',
    pledgeActionBtn: 'ಧ್ವಜಕ್ಕೆ ಗೌರವ ಸಲ್ಲಿಸಿ ಪ್ರತಿಜ್ಞೆ ಮಾಡಿ 🫡',
    pledgeDoneText: 'ನೀವು ರಾಷ್ಟ್ರಧ್ವಜಕ್ಕೆ ನಮಸ್ಕರಿಸಿದ್ದೀರಿ! ಜೈ ಹಿಂದ್! 🎉',
    quotesTitle: 'ದೇಶಭಕ್ತಿ ನುಡಿಮುತ್ತುಗಳು',
    quotesSubtitle: 'ಸ್ವಾತಂತ್ರ್ಯ ವೀರರಿಗೆ ನಮನಗಳು',
    frameTitle: 'ನಿಮ್ಮ ತ್ರಿವರ್ಣ DP / ಫೋಟೋ ಫ್ರೇಮ್ ರಚಿಸಿ 📸',
    frameSubtitle: '15 ಆಗಸ್ಟ್‌ಗಾಗಿ ನಿಮ್ಮ ಫೋಟೋ ಬಳಸಿ ದೇಶಭಕ್ತಿ ಫ್ರೇಮ್ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ',
    uploadPhotoBtn: 'ಫೋಟೋ ಆಯ್ಕೆಮಾಡಿ',
    downloadFrameBtn: 'HD DP ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ 📥',
    countdownDays: 'ದಿನಗಳು',
    countdownHours: 'ಗಂಟೆಗಳು',
    countdownMinutes: 'ನಿಮಿಷಗಳು',
    countdownSeconds: 'ಸೆಕೆಂಡುಗಳು',
    shayariList: [
      {
        quote: 'ಹಸಿರಾಗಲಿ ಈ ಭಾರತ, ಶಾಂತಿಯ ತೋಟವಾಗಲಿ ನಮ್ಮ ನಾಡು!',
        author: 'ಕನ್ನಡ ಸಂದೇಶ'
      },
      {
        quote: 'ದೇಶಕ್ಕಾಗಿ ಬಲಿದಾನ ನೀಡಿದ ವೀರರಿಗೆ ನಮ್ಮ ಕೋಟಿ ಕೋಟಿ ನಮನಗಳು!',
        author: 'ಅಮರ ಸಂದೇಶ'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15 ಆಗಸ್ಟ್ 2026 ವಿಶೇಷ ಸರ್ಪ್ರೈಸ್ ಉಡುಗೊರೆ* 🎁\n\n*${sender}* ನಿಮಗಾಗಿ ಸುಂದರವಾದ ಸ್ವಾತಂತ್ರ್ಯ ದಿನದ ಶುಭಾಶಯ ಕಾರ್ಡ್ ಕಳುಹಿಸಿದ್ದಾರೆ!\n\n👇 *ಉಡುಗೊರೆ ನೋಡಲು ಕೆಳಗಿನ ಲಿಂಕ್ ಕ್ಲಿಕ್ ಮಾಡಿ:* 👇\n${appUrl}\n\n_ನಿಮ್ಮ ಎಲ್ಲಾ ಸ್ನೇಹಿತರೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಿ! ಜೈ ಹಿಂದ್!_ 🇮🇳`
  },
  malayalam: {
    key: 'malayalam',
    label: 'Malayalam',
    nativeLabel: 'മലയാളം',
    flagIcon: '🇮🇳',
    tagline: 'എന്റെ ഭാരതം മഹത്തരം - 15 ഓഗസ്റ്റ് 2026',
    happyIndependence: 'സ്വാതന്ത്ര്യദിനാശംസകൾ!',
    yearCelebration: '15 ഓഗസ്റ്റ് 2026 - 80-ാം സ്വാതന്ത്ര്യദിനം',
    senderPrefix: '',
    senderSuffix: 'ന്റെയും കുടുംബത്തിന്റെയും ഹൃദയം നിറഞ്ഞ സ്വാതന്ത്ര്യദിനാശംസകൾ!',
    enterNamePlaceholder: 'നിങ്ങളുടെ പേര് നൽകുക...',
    createWishBtn: 'നിങ്ങളുടെ ആശംസ സൃഷ്ടിക്കുക ✨',
    shareOnWhatsAppBtn: 'വാട്സാപ്പിൽ എല്ലാവർക്കും അയക്കുക 🚀',
    shareOnTelegramBtn: 'ടെലിഗ്രാമിൽ പങ്കിടുക',
    shareOnFacebookBtn: 'ഫേസ്ബുക്കിൽ പങ്കിടുക',
    copyLinkBtn: 'ലിങ്ക് കോപ്പി ചെയ്യുക 📋',
    surpriseGiftTitle: 'നിങ്ങൾക്കായി ഒരു പ്രത്യേക ത്രിവർണ്ണ സർപ്രൈസ് സമ്മാനം! 🎁',
    tapToOpenText: 'സമ്മാനം തുറക്കാൻ പതാകയിൽ തൊടുക 🇮🇳',
    anthemTitle: 'ദേശീയഗാനം - ജന ഗണ മന 🎵',
    pledgeTitle: 'ദേശീയ പ്രതിജ്ഞ 2026 🇮🇳',
    pledgeText: 'ഭാരതം എന്റെ രാജ്യമാണ്. എല്ലാ ഭാരതീയരും എന്റെ സഹോദരീസഹോദരന്മാരാണ്. രാജ്യത്തിന്റെ ഐക്യത്തിനും പുരോഗതിക്കുമായി ഞാൻ നിലകൊള്ളും. ജയ് ഹിന്ദ്!',
    pledgeActionBtn: 'പതാകയെ സല്യൂട്ട് ചെയ്ത് പ്രതിജ്ഞയെടുക്കുക 🫡',
    pledgeDoneText: 'നിങ്ങൾ ദേശീയ പതാകയെ സല്യൂട്ട് ചെയ്തു! വന്ദേ മാതരം! 🎉',
    quotesTitle: 'ദേശഭക്തി ഉദ്ധരണികൾ',
    quotesSubtitle: 'സ്വാതന്ത്ര്യ സമര സേനാനികൾക്ക് പ്രണാമം',
    frameTitle: 'നിങ്ങളുടെ ത്രിവർണ്ണ DP ഫ്രെയിം നിർമ്മിക്കുക 📸',
    frameSubtitle: '15 ഓഗസ്റ്റിനായി നിങ്ങളുടെ ഫോട്ടോയിൽ ത്രിവർണ്ണ ബോർഡർ നൽകി വാട്സാപ്പ് DP ആക്കുക',
    uploadPhotoBtn: 'ഫോട്ടോ തിരഞ്ഞെടുക്കുക',
    downloadFrameBtn: 'HD DP ഡൗൺലോഡ് ചെയ്യുക 📥',
    countdownDays: 'ദിവസങ്ങൾ',
    countdownHours: 'മണിക്കൂറുകൾ',
    countdownMinutes: 'മിനിറ്റുകൾ',
    countdownSeconds: 'സെക്കൻഡുകൾ',
    shayariList: [
      {
        quote: 'സ്വാതന്ത്ര്യം ഓരോ ഭാരതീയന്റെയും ജന്മാവകാശമാണ്, അത് സംരക്ഷിക്കേണ്ടത് നമ്മുടെ കടമയാണ്!',
        author: 'ദേശീയ സന്ദേശം'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15 ഓഗസ്റ്റ് 2026 പ്രത്യേക സർപ്രൈസ് സമ്മാനം* 🎁\n\n*${sender}* നിങ്ങൾക്കായി ഒരു മനോഹരമായ സ്വാതന്ത്ര്യദിന സർപ്രൈസ് ആശംസ കാർഡ് അയച്ചിരിക്കുന്നു!\n\n👇 *സമ്മാനം കാണാൻ താഴെയുള്ള ലിങ്കിൽ ക്ലിക്ക് ചെയ്യുക:* 👇\n${appUrl}\n\n_എല്ലാ സുഹൃത്തുക്കളുമായും ഗ്രൂപ്പുകളുമായും ഷെയർ ചെയ്യുക! ജയ് ഹിന്ദ്!_ 🇮🇳`
  },
  punjabi: {
    key: 'punjabi',
    label: 'Punjabi',
    nativeLabel: 'ਪੰਜਾਬੀ',
    flagIcon: '🇮🇳',
    tagline: 'ਮੇਰਾ ਭਾਰਤ ਮਹਾਨ - 15 ਅਗਸਤ 2026',
    happyIndependence: 'ਸੁਤੰਤਰਤਾ ਦਿਵਸ ਦੀਆਂ ਲੱਖ-ਲੱਖ ਵਧਾਈਆਂ!',
    yearCelebration: '15 ਅਗਸਤ 2026 - 80ਵਾਂ ਆਜ਼ਾਦੀ ਦਿਹਾੜਾ',
    senderPrefix: '',
    senderSuffix: 'ਵੱਲੋਂ ਤੁਹਾਨੂੰ ਅਤੇ ਤੁਹਾਡੇ ਸਾਰੇ ਪਰਿਵਾਰ ਨੂੰ ਸੁਤੰਤਰਤਾ ਦਿਵਸ ਦੀਆਂ ਹਾਰਦਿਕ ਮੁਬਾਰਕਾਂ!',
    enterNamePlaceholder: 'ਆਪਣਾ ਨਾਮ ਇੱਥੇ ਲਿਖੋ...',
    createWishBtn: 'ਆਪਣੀ ਖ਼ਾਸ ਵਧਾਈ ਬਣਾਓ ✨',
    shareOnWhatsAppBtn: 'ਵ੍ਹਟਸਐਪ ਤੇ ਸਭ ਨੂੰ ਭੇਜੋ 🚀',
    shareOnTelegramBtn: 'ਟੈਲੀਗ੍ਰਾਮ ਤੇ ਭੇਜੋ',
    shareOnFacebookBtn: 'ਫੇਸਬੁੱਕ ਤੇ ਸ਼ੇਅਰ ਕਰੋ',
    copyLinkBtn: 'ਲਿੰਕ ਕਾਪੀ ਕਰੋ 📋',
    surpriseGiftTitle: 'ਤੁਹਾਡੇ ਲਈ ਇੱਕ ਖ਼ਾਸ ਤਿਰੰਗਾ ਸਰਪ੍ਰਾਈਜ਼ ਗਿਫਟ! 🎁',
    tapToOpenText: 'ਤੋਹਫ਼ਾ ਖੋਲ੍ਹਣ ਲਈ ਤਿਰੰਗੇ ਤੇ ਕਲਿੱਕ ਕਰੋ 🇮🇳',
    anthemTitle: 'ਰਾਸ਼ਟਰੀ ਗਾਣ - ਜਨ ਗਣ ਮਨ 🎵',
    pledgeTitle: 'ਰਾਸ਼ਟਰੀ ਪ੍ਰਣ 2026 🇮🇳',
    pledgeText: 'ਭਾਰਤ ਮੇਰਾ ਦੇਸ਼ ਹੈ। ਸਾਰੇ ਭਾਰਤੀ ਮੇਰੇ ਭੈਣ-ਭਰਾ ਹਨ। ਦੇਸ਼ ਦੀ ਏਕਤਾ ਅਤੇ ਤਰੱਕੀ ਲਈ ਮੈਂ ਹਮੇਸ਼ਾ ਤਤਪਰ ਰਹਾਂਗਾ। ਜੈ ਹਿੰਦ!',
    pledgeActionBtn: 'ਤਿਰੰਗੇ ਨੂੰ ਸਲੂਟ ਤੇ ਪ੍ਰਣ ਲਵੋ 🫡',
    pledgeDoneText: 'ਤੁਸੀਂ ਕੌਮੀ ਝੰਡੇ ਨੂੰ ਸਲੂਟ ਕੀਤਾ! ਜੈ ਹਿੰਦ! 🎉',
    quotesTitle: 'ਦੇਸ਼ਭਗਤੀ ਦੇ ਸੁਨੇਹੇ ਅਤੇ ਸ਼ਾਇਰੀ',
    quotesSubtitle: 'ਸ਼ਹੀਦ-ਏ-ਆਜ਼ਮ ਭਗਤ ਸਿੰਘ ਅਤੇ ਸ਼ਹੀਦਾਂ ਨੂੰ ਕੋਟਿ-ਕੋਟਿ ਪ੍ਰਣਾਮ',
    frameTitle: 'ਆਪਣੀ ਤਿਰੰਗਾ DP / ਫੋਟੋ ਫਰੇਮ ਬਣਾਓ 📸',
    frameSubtitle: '15 ਅਗਸਤ ਲਈ ਆਪਣੀ ਫੋਟੋ ਨਾਲ ਤਿਰੰਗਾ ਡੀਪੀ ਬਣਾਓ ਅਤੇ ਵ੍ਹਟਸਐਪ ਤੇ ਲਗਾਓ',
    uploadPhotoBtn: 'ਫੋਟੋ ਚੁਣੋ',
    downloadFrameBtn: 'HD DP ਡਾਊਨਲੋਡ ਕਰੋ 📥',
    countdownDays: 'ਦਿਨ',
    countdownHours: 'ਘੰਟੇ',
    countdownMinutes: 'ਮਿੰਟ',
    countdownSeconds: 'ਸਕਿੰਟ',
    shayariList: [
      {
        quote: 'ਇਨਕਲਾਬ ਜ਼ਿੰਦਾਬਾਦ! ਜ਼ਿੰਦਗੀ ਤਾਂ ਆਪਣੇ ਦਮ ਤੇ ਜਿਊਂਈ ਜਾਂਦੀ ਹੈ, ਦੂਜਿਆਂ ਦੇ ਮੋਢਿਆਂ ਤੇ ਤਾਂ ਸਿਰਫ਼ ਜਨਾਜ਼ੇ ਉੱਠਦੇ ਹਨ!',
        author: 'ਸ਼ਹੀਦ ਭਗਤ ਸਿੰਘ'
      },
      {
        quote: 'ਮੇਰਾ ਰੰਗ ਦੇ ਬਸੰਤੀ ਚੋਲਾ, ਮਾਏ ਰੰਗ ਦੇ ਬਸੰਤੀ ਚੋਲਾ!',
        author: 'ਅਮਰ ਸ਼ਹੀਦ'
      }
    ],
    viralMessageTemplate: (sender: string, appUrl: string) => 
      `🇮🇳 *15 ਅਗਸਤ 2026 ਸਰਪ੍ਰਾਈਜ਼ ਗਿਫਟ* 🎁\n\n*${sender}* ਨੇ ਤੁਹਾਡੇ ਲਈ 15 ਅਗਸਤ ਆਜ਼ਾਦੀ ਦਿਹਾੜੇ ਦਾ ਬਹੁਤ ਹੀ ਖ਼ਾਸ ਸਰਪ੍ਰਾਈਜ਼ ਸੁਨੇਹਾ ਭੇਜਿਆ ਹੈ!\n\n👇 *ਹੇਠਾਂ ਦਿੱਤੇ ਨੀਲੇ ਲਿੰਕ ਤੇ ਕਲਿੱਕ ਕਰਕੇ ਦੇਖੋ:* 👇\n${appUrl}\n\n_ਸਾਰੇ ਦੋਸਤਾਂ ਅਤੇ ਵ੍ਹਟਸਐਪ ਗਰੁੱਪਾਂ ਵਿੱਚ ਜ਼ਰੂਰ ਸ਼ੇਅਰ ਕਰੋ! ਬੋਲੇ ਸੋ ਨਿਹਾਲ, ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ!_ 🇮🇳`
  }
};
