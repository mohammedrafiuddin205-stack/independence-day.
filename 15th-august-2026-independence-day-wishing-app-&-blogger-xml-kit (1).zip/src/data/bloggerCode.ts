export const BLOGGER_FULL_XML_THEME = `<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html b:css='false' b:defaultwidgetversion='2' b:layoutsversion='3' expr:dir='data:blog.languageDirection' xmlns='http://www.w3.org/1999/xhtml' xmlns:b='http://www.google.com/2005/gml/b' xmlns:data='http://www.google.com/2005/gml/data' xmlns:expr='http://www.google.com/2005/gml/expr'>
<head>
  <meta charset='utf-8'/>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no' name='viewport'/>
  <title>🇮🇳 Happy 15th August 2026 Independence Day Wishing Surprise</title>
  
  <!-- SEO & WhatsApp Viral OpenGraph Meta Tags -->
  <meta content='A special 15th August 2026 Independence Day musical surprise gift for you! Click to open your personalized wishing card.' name='description'/>
  <meta content='15 august 2026, happy independence day 2026, wishing script, blogger xml theme, 15 august wishing website' name='keywords'/>
  <meta content='Happy 15th August 2026 Independence Day 🇮🇳' property='og:title'/>
  <meta content='🎁 Special Tiranga surprise card waiting for you! Click to open with your name.' property='og:description'/>
  <meta content='https://images.unsplash.com/photo-1532375810709-75b1da00537c?w=1200&amp;auto=format&amp;fit=crop&amp;q=80' property='og:image'/>
  <meta content='website' property='og:type'/>
  <meta content='#FF9933' name='theme-color'/>
  
  <!-- Google Fonts -->
  <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700;900&amp;family=Rozha+One&amp;display=swap' rel='stylesheet'/>
  <script src='https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js'></script>
  
  <!-- Adsterra Social Bar / Popunder Script Placement Here (Optional) -->
  <!-- <script type='text/javascript' src='//plYOUR_ADSTERRA_KEY.highrevenuegate.com/xx/yy/zz.js'></script> -->

  <b:skin><![CDATA[
    * { margin:0; padding:0; box-sizing:border-box; font-family:'Poppins', sans-serif; }
    body {
      background: radial-gradient(circle at 50% 20%, #fff7ed 0%, #ffedd5 50%, #fef3c7 100%);
      min-height: 100vh;
      color: #1e293b;
      overflow-x: hidden;
      text-align: center;
      padding-bottom: 90px;
    }
    .tricolor-bar {
      height: 8px;
      width: 100%;
      background: linear-gradient(90deg, #FF9933 0%, #FF9933 33.3%, #ffffff 33.3%, #ffffff 66.6%, #138808 66.6%, #138808 100%);
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .container {
      max-width: 500px;
      margin: 0 auto;
      padding: 16px;
    }
    .header-badge {
      display: inline-block;
      background: linear-gradient(135deg, #FF9933, #e65100);
      color: #fff;
      font-weight: 700;
      font-size: 13px;
      padding: 6px 18px;
      border-radius: 999px;
      box-shadow: 0 4px 12px rgba(255,153,51,0.4);
      margin-bottom: 12px;
      letter-spacing: 0.5px;
      animation: pulse 2s infinite;
    }
    .sender-box {
      background: rgba(255, 255, 255, 0.95);
      border: 2px dashed #FF9933;
      border-radius: 16px;
      padding: 14px;
      margin: 12px 0;
      box-shadow: 0 10px 25px rgba(255,153,51,0.15);
    }
    .sender-name {
      font-size: 26px;
      font-weight: 900;
      color: #e65100;
      text-transform: uppercase;
      text-shadow: 1px 1px 0 #ffd180;
      letter-spacing: 1px;
      animation: glow 1.5s ease-in-out infinite alternate;
    }
    .chakra-spin {
      width: 80px;
      height: 80px;
      margin: 10px auto;
      animation: rotate 12s linear infinite;
    }
    .greeting-title {
      font-family: 'Rozha One', serif;
      font-size: 32px;
      line-height: 1.2;
      background: linear-gradient(180deg, #FF9933 20%, #1e3a8a 50%, #138808 80%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin: 10px 0;
      font-weight: 900;
    }
    .flag-banner {
      width: 100%;
      border-radius: 14px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
      margin: 12px 0;
      border: 3px solid #fff;
    }
    .countdown-grid {
      display: flex;
      justify-content: center;
      gap: 8px;
      margin: 16px 0;
    }
    .countdown-card {
      background: #fff;
      border-radius: 12px;
      padding: 10px 8px;
      min-width: 65px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      border: 1px solid #fed7aa;
    }
    .countdown-num {
      font-size: 22px;
      font-weight: 800;
      color: #c2410c;
    }
    .countdown-lbl {
      font-size: 11px;
      font-weight: 600;
      color: #64748b;
      text-transform: uppercase;
    }
    .shayari-card {
      background: #ffffff;
      border-left: 5px solid #FF9933;
      border-right: 5px solid #138808;
      border-radius: 12px;
      padding: 16px;
      font-size: 15px;
      line-height: 1.6;
      font-weight: 600;
      color: #1e293b;
      margin: 16px 0;
      box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    }
    .input-box-container {
      background: #fff;
      padding: 16px;
      border-radius: 18px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.08);
      margin: 20px 0;
      border: 2px solid #fdba74;
    }
    .input-name {
      width: 100%;
      padding: 14px 18px;
      border-radius: 12px;
      border: 2px solid #fb923c;
      font-size: 17px;
      font-weight: 600;
      text-align: center;
      outline: none;
      transition: all 0.2s;
    }
    .input-name:focus {
      border-color: #ea580c;
      box-shadow: 0 0 0 4px rgba(251,146,60,0.25);
    }
    .btn-create {
      width: 100%;
      margin-top: 10px;
      padding: 14px;
      background: linear-gradient(135deg, #f97316, #ea580c);
      color: white;
      font-weight: 700;
      font-size: 16px;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      box-shadow: 0 6px 16px rgba(234,88,12,0.35);
      transition: transform 0.1s;
    }
    .btn-create:active { transform: scale(0.98); }
    .whatsapp-sticky-bar {
      position: fixed;
      bottom: 0;
      left: 0;
      width: 100%;
      background: rgba(255,255,255,0.96);
      backdrop-filter: blur(10px);
      padding: 10px 16px;
      box-shadow: 0 -4px 20px rgba(0,0,0,0.15);
      z-index: 999;
      display: flex;
      justify-content: center;
    }
    .btn-whatsapp {
      max-width: 480px;
      width: 100%;
      background: #25D366;
      color: white;
      font-size: 17px;
      font-weight: 800;
      padding: 14px 20px;
      border-radius: 999px;
      text-decoration: none;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      box-shadow: 0 6px 20px rgba(37,211,102,0.5);
      animation: bounce 1.8s infinite;
    }
    .ad-placeholder {
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 8px;
      padding: 12px;
      margin: 14px 0;
      font-size: 12px;
      color: #94a3b8;
    }
    @keyframes rotate { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    @keyframes pulse { 0%,100% { transform: scale(1); } 50% { transform: scale(1.05); } }
    @keyframes glow { from { text-shadow: 0 0 10px #ff9933; } to { text-shadow: 0 0 20px #e65100; } }
    @keyframes bounce { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-5px); } }
  ]]></b:skin>
</head>
<body>
  <div class='tricolor-bar'></div>

  <div class='container'>
    <div class='header-badge'>🇮🇳 15th AUGUST 2026 CELEBRATION 🇮🇳</div>

    <div class='sender-box'>
      <div style='font-size:14px; font-weight:600; color:#64748b;'>A Special Independence Day Wish From:</div>
      <div class='sender-name' id='displaySenderName'>YOUR FRIEND</div>
      <div style='font-size:13px; color:#475569; margin-top:4px;'>Sending you &amp; your family heartfelt Tiranga greetings!</div>
    </div>

    <!-- Adsterra Top Banner Ad (300x250 or 728x90) -->
    <div class='ad-placeholder'>
      <!-- Paste your Adsterra 300x250 Banner Code Below -->
      <!-- <script type="text/javascript"> atOptions = { 'key' : 'YOUR_BANNER_KEY', 'format' : 'iframe', 'height' : 250, 'width' : 300, 'params' : {} }; </script> -->
      <!-- <script type="text/javascript" src="//www.highperformanceformat.com/YOUR_BANNER_KEY/invoke.js"></script> -->
      <span style='color:#64748b; font-weight:600;'>[🇮🇳 Adsterra Top High-CPM Ad Slot]</span>
    </div>

    <svg class='chakra-spin' viewBox='0 0 100 100'>
      <circle cx='50' cy='50' r='45' fill='none' stroke='#000080' stroke-width='4'/>
      <circle cx='50' cy='50' r='8' fill='#000080'/>
      <!-- 24 Spokes of Ashoka Chakra -->
      <g stroke='#000080' stroke-width='2'>
        <line x1='50' y1='5' x2='50' y2='95'/>
        <line x1='5' y1='50' x2='95' y2='50'/>
        <line x1='18.2' y1='18.2' x2='81.8' y2='81.8'/>
        <line x1='18.2' y1='81.8' x2='81.8' y2='18.2'/>
        <line x1='32.7' y1='8.4' x2='67.3' y2='91.6'/>
        <line x1='8.4' y1='32.7' x2='91.6' y2='67.3'/>
        <line x1='8.4' y1='67.3' x2='91.6' y2='32.7'/>
        <line x1='32.7' y1='91.6' x2='67.3' y2='8.4'/>
        <line x1='67.3' y1='8.4' x2='32.7' y2='91.6'/>
        <line x1='91.6' y1='32.7' x2='8.4' y2='67.3'/>
        <line x1='91.6' y1='67.3' x2='8.4' y2='32.7'/>
        <line x1='67.3' y1='91.6' x2='32.7' y2='8.4'/>
      </g>
    </svg>

    <h1 class='greeting-title'>HAPPY 80th<br/>INDEPENDENCE DAY</h1>
    <p style='font-weight:700; color:#1e3a8a; font-size:16px; margin-bottom:10px;'>15th August 2026 - Mera Bharat Mahan 🇮🇳</p>

    <img class='flag-banner' src='https://images.unsplash.com/photo-1532375810709-75b1da00537c?w=800&amp;auto=format&amp;fit=crop&amp;q=80' alt='Indian Flag Tiranga'/>

    <!-- Live Countdown Timer -->
    <div class='countdown-grid'>
      <div class='countdown-card'><div class='countdown-num' id='daysBox'>00</div><div class='countdown-lbl'>Days</div></div>
      <div class='countdown-card'><div class='countdown-num' id='hoursBox'>00</div><div class='countdown-lbl'>Hours</div></div>
      <div class='countdown-card'><div class='countdown-num' id='minsBox'>00</div><div class='countdown-lbl'>Mins</div></div>
      <div class='countdown-card'><div class='countdown-num' id='secsBox'>00</div><div class='countdown-lbl'>Secs</div></div>
    </div>

    <!-- Patriotic Shayari -->
    <div class='shayari-card'>
      &ldquo;कुछ नशा तिरंगे की आन का है, कुछ नशा मातृभूमि की शान का है!<br/>
      हम लहराएंगे हर जगह ये तिरंगा, नशा ये हिंदुस्तान के सम्मान का है!&rdquo;<br/>
      <span style='color:#ea580c; font-size:13px; font-weight:700; margin-top:8px; display:inline-block;'>— जय हिन्द! वन्दे मातरम्!</span>
    </div>

    <!-- Name Customizer Box -->
    <div class='input-box-container'>
      <div style='font-size:16px; font-weight:700; color:#9a3412; margin-bottom:8px;'>✨ Apna Naam Likhein Aur Wish Bhejein:</div>
      <input type='text' id='userNameInput' class='input-name' placeholder='Enter Your Name Here...' maxlength='30'/>
      <button class='btn-create' onclick='createPersonalWish()'>Generate My Name Wish Card 🚀</button>
    </div>

    <!-- Adsterra Native Banner / Middle Ad -->
    <div class='ad-placeholder'>
      <!-- Paste your Adsterra Native Banner or In-Page Push Code -->
      <span style='color:#64748b; font-weight:600;'>[🇮🇳 Adsterra Middle Native Ad Slot]</span>
    </div>

    <div style='background:#f1f5f9; padding:14px; border-radius:12px; font-size:13px; color:#64748b; margin-top:16px;'>
      ❤️ Made with Pride for India 2026. Share love and brotherhood with every Indian across the globe!
    </div>
  </div>

  <!-- Blogger Body Section Required by XML Engine -->
  <div style='display:none;'><b:section id='main' maxwidgets='1' showaddelement='no'/></div>

  <!-- Sticky Viral WhatsApp Button -->
  <div class='whatsapp-sticky-bar'>
    <a href='#' class='btn-whatsapp' id='whatsappBtn' onclick='shareToWhatsApp(event)'>
      <span>👉 Share on WhatsApp to 10 Friends 🚀</span>
    </a>
  </div>

  <script>
    // Extract Name from URL (?n=... or ?name=...)
    function getQueryParam(name) {
      var urlParams = new URLSearchParams(window.location.search);
      return urlParams.get(name);
    }

    var currentSender = getQueryParam('n') || getQueryParam('name') || 'A Proud Indian';
    document.getElementById('displaySenderName').innerText = decodeURIComponent(currentSender);

    // Countdown Timer for 15 August 2026
    function updateCountdown() {
      var target = new Date('August 15, 2026 00:00:00 GMT+0530').getTime();
      var now = new Date().getTime();
      var diff = target - now;

      if (diff &lt; 0) {
        document.getElementById('daysBox').innerText = '00';
        document.getElementById('hoursBox').innerText = '00';
        document.getElementById('minsBox').innerText = '00';
        document.getElementById('secsBox').innerText = '00';
        return;
      }

      var d = Math.floor(diff / (1000 * 60 * 60 * 24));
      var h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      var m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      var s = Math.floor((diff % (1000 * 60)) / 1000);

      document.getElementById('daysBox').innerText = d &lt; 10 ? '0' + d : d;
      document.getElementById('hoursBox').innerText = h &lt; 10 ? '0' + h : h;
      document.getElementById('minsBox').innerText = m &lt; 10 ? '0' + m : m;
      document.getElementById('secsBox').innerText = s &lt; 10 ? '0' + s : s;
    }
    setInterval(updateCountdown, 1000);
    updateCountdown();

    // Confetti burst on load
    window.addEventListener('load', function() {
      if (typeof confetti === 'function') {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FF9933', '#FFFFFF', '#138808', '#000080']
        });
      }
    });

    function createPersonalWish() {
      var input = document.getElementById('userNameInput').value.trim();
      if (!input) {
        alert('Please enter your name first!');
        return;
      }
      currentSender = input;
      document.getElementById('displaySenderName').innerText = input;
      if (typeof confetti === 'function') {
        confetti({ particleCount: 120, spread: 90, colors: ['#FF9933', '#FFFFFF', '#138808'] });
      }
      alert('Your name wish has been created! Now click the green WhatsApp button below to send to your friends.');
    }

    function shareToWhatsApp(e) {
      e.preventDefault();
      var sender = currentSender || 'Your Friend';
      var baseUrl = window.location.protocol + '//' + window.location.host + window.location.pathname;
      var shareUrl = baseUrl + '?n=' + encodeURIComponent(sender);
      
      var text = "🇮🇳 *15 AUGUST 2026 SURPRISE GIFT* 🎁\\n\\n*" + sender + "* ne aapke liye ek bahut pyara 15 August Tiranga Surprise Card bheja hai!\\n\\n👇 *Neeche link par click karke dekhein:* 👇\\n" + shareUrl + "\\n\\n_Apne sabhi doston aur groups mein forward karein! Jai Hind!_ 🇮🇳";
      
      window.open('https://api.whatsapp.com/send?text=' + encodeURIComponent(text), '_blank');
    }
  </script>
</body>
</html>`;

export const BLOGGER_HTML_POST_EMBED = `<div class="independence-day-post-wrapper" style="max-width:600px; margin:0 auto; text-align:center; font-family:sans-serif; background:#fff7ed; padding:20px; border-radius:16px; border:2px solid #FF9933;">
  <h2 style="color:#e65100; font-size:24px; font-weight:800;">🇮🇳 Happy 15th August 2026 Independence Day Wishing Script</h2>
  <p style="color:#475569; font-size:15px; margin:10px 0;">Create your personalized Tiranga greeting with music, tricolor confetti, and your name to share on WhatsApp!</p>
  
  <!-- Embedded Wishing Widget iFrame or Direct Link -->
  <div style="margin:20px 0; padding:15px; background:#fff; border-radius:12px; box-shadow:0 4px 12px rgba(0,0,0,0.05);">
    <h3 style="color:#000080; margin-bottom:10px;">👇 Touch Below to Open Your 15 August Surprise Card 👇</h3>
    <a href="#wish" style="display:inline-block; background:linear-gradient(135deg, #FF9933, #138808); color:#fff; font-weight:700; font-size:18px; padding:12px 28px; border-radius:30px; text-decoration:none; box-shadow:0 4px 15px rgba(255,153,51,0.4);">Open Tiranga Surprise 🎁</a>
  </div>
</div>`;
