export type LanguageKey = 
  | 'hinglish' 
  | 'hindi' 
  | 'english' 
  | 'urdu' 
  | 'telugu' 
  | 'tamil' 
  | 'bengali' 
  | 'marathi' 
  | 'gujarati' 
  | 'kannada' 
  | 'malayalam' 
  | 'punjabi';

export interface LanguageData {
  key: LanguageKey;
  label: string;
  nativeLabel: string;
  flagIcon: string;
  tagline: string;
  happyIndependence: string;
  yearCelebration: string;
  senderPrefix: string;
  senderSuffix: string;
  enterNamePlaceholder: string;
  createWishBtn: string;
  shareOnWhatsAppBtn: string;
  shareOnTelegramBtn: string;
  shareOnFacebookBtn: string;
  copyLinkBtn: string;
  surpriseGiftTitle: string;
  tapToOpenText: string;
  anthemTitle: string;
  pledgeTitle: string;
  pledgeText: string;
  pledgeActionBtn: string;
  pledgeDoneText: string;
  quotesTitle: string;
  quotesSubtitle: string;
  frameTitle: string;
  frameSubtitle: string;
  uploadPhotoBtn: string;
  downloadFrameBtn: string;
  countdownDays: string;
  countdownHours: string;
  countdownMinutes: string;
  countdownSeconds: string;
  shayariList: Array<{
    quote: string;
    author: string;
  }>;
  viralMessageTemplate: (sender: string, appUrl: string) => string;
}

export interface DPFrameStyle {
  id: string;
  name: string;
  borderClass: string;
  badgeText: string;
  ribbonColor: string;
}
